<?php
/**
 * Hussein Bawab Portfolio — Fallback Template Loader (index.php)
 * All WordPress migrations are marked clearly.
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct file execution
}

get_header(); // ← WP-MIGRATION: Header load
?>

<div class="max-w-6xl mx-auto px-4 py-24">
    <div class="border border-neutral-200 dark:border-neutral-800 rounded-2xl p-8 bg-white dark:bg-neutral-950 shadow-xs max-w-2xl mx-auto text-center">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <h1 class="text-3xl font-sans font-black mb-4 text-neutral-900 dark:text-neutral-50"><?php the_title(); ?></h1>
            <div class="text-sm text-neutral-500 dark:text-neutral-400 font-sans leading-relaxed text-left max-w-xl mx-auto space-y-4">
                <?php the_content(); ?>
            </div>
        <?php endwhile; else : ?>
            <h1 class="text-2xl font-sans font-black mb-4 text-neutral-900 dark:text-neutral-50"><?php esc_html_e('Seite nicht gefunden', 'hb-portfolio'); ?></h1>
            <p class="text-xs text-neutral-500 dark:text-neutral-400 font-mono"><?php esc_html_e('Leider existiert dieser Inhalt hier nicht.', 'hb-portfolio'); ?></p>
        <?php endif; ?>
    </div>
</div>

<?php 
get_footer(); // ← WP-MIGRATION: Footer load
