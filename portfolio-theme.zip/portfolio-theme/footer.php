    </main>

    <!-- FOOTER VIEW -->
    <footer class="bg-neutral-50 dark:bg-neutral-950 py-12 border-t border-neutral-200 dark:border-neutral-900">
      <div class="max-w-6xl mx-auto px-3 sm:px-6 md:px-12 lg:px-20 xl:px-32 flex flex-col items-center justify-center gap-6">
        
        <div class="text-center">
          <p class="text-xs text-neutral-500 dark:text-neutral-400 font-sans">
            &copy; <?php echo date('Y'); ?> Hussein Bawab. Alle Rechte vorbehalten.
          </p>
          <p class="text-[10px] text-neutral-400 dark:text-neutral-500 font-mono mt-1">
            Entwickelt als eigenständiges WordPress Custom Theme mit extrem geschwindigkeitsoptimiertem Code.
          </p>
        </div>

      </div>
    </footer>
    </div> <!-- Close #portfolio-content-root -->

    <!-- Dynamic Layout Engine Overlay & Floating Trigger -->
    <div id="layout-engine-popover" class="layout-widget-popover max-w-[320px] sm:max-w-xs w-[calc(100vw-2.5rem)] rounded-2xl border border-neutral-300 dark:border-neutral-800 bg-white dark:bg-[#0a0a0c] p-5 shadow-2xl transition-all duration-200 transform scale-95 opacity-0 origin-bottom-right pointer-events-none hidden">
      <!-- Card Header -->
      <div class="flex items-center justify-between mb-4 pb-2 border-b border-neutral-200 dark:border-neutral-900">
        <div class="flex items-center gap-2">
          <!-- Sliders controls icon -->
          <svg class="w-4 h-4 text-brand-purple animate-spin-slow" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <line x1="4" y1="21" x2="4" y2="14"></line>
            <line x1="4" y1="10" x2="4" y2="3"></line>
            <line x1="12" y1="21" x2="12" y2="12"></line>
            <line x1="12" y1="8" x2="12" y2="3"></line>
            <line x1="20" y1="21" x2="20" y2="16"></line>
            <line x1="20" y1="12" x2="20" y2="3"></line>
            <line x1="1" y1="14" x2="7" y2="14"></line>
            <line x1="9" y1="8" x2="15" y2="8"></line>
            <line x1="17" y1="16" x2="23" y2="16"></line>
          </svg>
          <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-neutral-950 dark:text-white">
            Live-Layout
          </h3>
        </div>
        <button id="btn-reset-layout" class="text-[10px] font-mono hover:text-neutral-950 dark:hover:text-white text-neutral-600 dark:text-neutral-400 hover:underline transition-all flex items-center gap-1 cursor-pointer">
          <!-- RefreshCw icon -->
          <svg class="w-2.5 h-2.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <polyline points="23 4 23 10 17 10"></polyline>
            <polyline points="1 20 1 14 7 14"></polyline>
            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
          </svg>
          <span>Zurücksetzen</span>
        </button>
      </div>

      <!-- Parameters selections panel -->
      <div class="flex flex-col gap-4">
        
        <!-- Option 1: Accent Colors picker -->
        <div class="flex flex-col">
          <label class="text-[10px] font-mono text-neutral-600 dark:text-neutral-400 uppercase tracking-widest mb-3 block font-bold">Akzentfarbe</label>
          <div class="flex gap-2.5">
            <button id="color-picker-cyan" class="clr-picker-btn w-6 h-6 rounded-full bg-cyan-500 cursor-pointer transition-all flex items-center justify-center ring-2 ring-[#070708] dark:ring-white ring-offset-2 ring-offset-[#070708]" aria-label="Akzentfarbe cyan" data-color="cyan">
              <svg class="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>
            </button>
            <button id="color-picker-purple" class="clr-picker-btn w-6 h-6 rounded-full bg-violet-500 cursor-pointer transition-all flex items-center justify-center" aria-label="Akzentfarbe purple" data-color="purple">
              <svg class="w-3.5 h-3.5 text-white hidden" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>
            </button>
            <button id="color-picker-amber" class="clr-picker-btn w-6 h-6 rounded-full bg-amber-500 cursor-pointer transition-all flex items-center justify-center" aria-label="Akzentfarbe amber" data-color="amber">
              <svg class="w-3.5 h-3.5 text-white hidden" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>
            </button>
            <button id="color-picker-rose" class="clr-picker-btn w-6 h-6 rounded-full bg-rose-500 cursor-pointer transition-all flex items-center justify-center" aria-label="Akzentfarbe rose" data-color="rose">
              <svg class="w-3.5 h-3.5 text-white hidden" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>
            </button>
          </div>
        </div>

        <!-- Option 2: Font choices picker -->
        <div class="flex flex-col">
          <label class="text-[10px] font-mono text-neutral-600 dark:text-neutral-400 uppercase tracking-widest mb-3 block font-bold">Schriftart</label>
          <div class="grid grid-cols-3 gap-1 bg-neutral-200/60 dark:bg-neutral-900/85 p-0.5 rounded-lg">
            <button id="font-btn-sans" class="font-selector-btn py-1 px-1.5 rounded text-[10px] font-semibold text-center uppercase cursor-pointer transition-all text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 flex items-center justify-center h-7 select-none leading-none" data-font="sans">sans</button>
            <button id="font-btn-serif" class="font-selector-btn py-1 px-1.5 rounded text-[10px] font-bold text-center uppercase cursor-pointer transition-all bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-xs flex items-center justify-center h-7 select-none leading-none" data-font="serif">serif</button>
            <button id="font-btn-mono" class="font-selector-btn py-1 px-1.5 rounded text-[10px] font-semibold text-center uppercase cursor-pointer transition-all text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 flex items-center justify-center h-7 select-none leading-none" data-font="mono">mono</button>
          </div>
        </div>

        <!-- Option 3: Densities choices picker -->
        <div class="flex flex-col">
          <label class="text-[10px] font-mono text-neutral-600 dark:text-neutral-400 uppercase tracking-widest mb-3 block font-bold">Abstand</label>
          <div class="grid grid-cols-3 gap-1 bg-neutral-200/60 dark:bg-neutral-900/85 p-0.5 rounded-lg">
            <button id="density-btn-compact" class="density-selector-btn py-1 px-1.5 rounded text-[10px] font-semibold text-center uppercase cursor-pointer transition-all text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 flex items-center justify-center h-7 select-none leading-none" data-density="compact">kompakt</button>
            <button id="density-btn-cozy" class="density-selector-btn py-1 px-1.5 rounded text-[10px] font-bold text-center uppercase cursor-pointer transition-all bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-xs flex items-center justify-center h-7 select-none leading-none" data-density="cozy">gemütlich</button>
            <button id="density-btn-relaxed" class="density-selector-btn py-1 px-1.5 rounded text-[10px] font-semibold text-center uppercase cursor-pointer transition-all text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 flex items-center justify-center h-7 select-none leading-none" data-density="relaxed">luftig</button>
          </div>
        </div>

        <!-- Option 4: Font sizes choices picker -->
        <div class="flex flex-col">
          <label class="text-[10px] font-mono text-neutral-600 dark:text-neutral-400 uppercase tracking-widest mb-3 block font-bold">Schriftgröße</label>
          <div class="grid grid-cols-3 gap-1 bg-neutral-200/60 dark:bg-neutral-900/85 p-0.5 rounded-lg">
            <button id="size-btn-small" class="size-selector-btn py-1 px-1.5 rounded text-[10px] font-semibold text-center uppercase cursor-pointer transition-all text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 flex items-center justify-center h-7 select-none leading-none" data-size="small">klein</button>
            <button id="size-btn-medium" class="size-selector-btn py-1 px-1.5 rounded text-[10px] font-bold text-center uppercase cursor-pointer transition-all bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-xs flex items-center justify-center h-7 select-none leading-none" data-size="medium">mittel</button>
            <button id="size-btn-large" class="size-selector-btn py-1 px-1.5 rounded text-[10px] font-semibold text-center uppercase cursor-pointer transition-all text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 flex items-center justify-center h-7 select-none leading-none" data-size="large">groß</button>
          </div>
        </div>

        <!-- Accessibility Option: Double Contrast -->
        <div class="flex items-center justify-between border-t border-neutral-200 dark:border-neutral-900 pt-3 mt-1">
          <span class="text-[10px] font-mono text-neutral-600 dark:text-neutral-400 uppercase font-bold tracking-widest">Doppelkontrast (A11y)</span>
          <label class="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" id="toggle-high-contrast" class="sr-only peer">
            <div class="w-7 h-4 bg-neutral-200 rounded-full dark:bg-neutral-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:height-3 after:width-3 after:transition-all dark:border-gray-600 peer-checked:bg-brand-accent h-4 w-7 after:h-3 after:w-3"></div>
          </label>
        </div>

      </div>

      <!-- Footer specifications -->
      <div class="mt-4 pt-2 border-t border-neutral-200 dark:border-neutral-900 flex items-center gap-1.5 text-[9px] text-neutral-600 dark:text-neutral-400 font-mono">
        <!-- Eye observation icon -->
        <svg class="w-3 h-3 text-brand-purple shrink-0 animate-pulse" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
          <circle cx="12" cy="12" r="3"></circle>
        </svg>
        <span class="truncate">
          Layout: <strong id="debug-layout-string" class="text-neutral-800 dark:text-neutral-200 font-bold">Editorial Serif / Cozy</strong>
        </span>
      </div>
    </div>

    <!-- Floating Action Button for Layout Engine -->
    <button id="btn-toggle-layout-engine" class="layout-widget-trigger bg-brand-accent hover:opacity-90 text-neutral-950 rounded-full shadow-[0_0_20px_rgba(6,182,212,0.4)] hover:scale-105 active:scale-95 transition-all cursor-pointer border border-brand-accent/30 group relative flex items-center justify-center p-0" aria-label="Layout-Steuerung umschalten">
      <svg class="w-4 h-4 transition-transform duration-500 group-hover:rotate-45 text-neutral-950 shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
        <line x1="4" y1="21" x2="4" y2="14"></line>
        <line x1="4" y1="10" x2="4" y2="3"></line>
        <line x1="12" y1="21" x2="12" y2="12"></line>
        <line x1="12" y1="8" x2="12" y2="3"></line>
        <line x1="20" y1="21" x2="20" y2="16"></line>
        <line x1="20" y1="12" x2="20" y2="3"></line>
        <line x1="1" y1="14" x2="7" y2="14"></line>
        <line x1="9" y1="8" x2="15" y2="8"></line>
        <line x1="17" y1="16" x2="23" y2="16"></line>
      </svg>
      <span class="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0 block"></span>
    </button>


    <!-- KEYBOARD OVERLAY COMMAND CENTER MENU MODAL -->
    <div id="command-menu-modal" class="fixed inset-0 z-50 overflow-hidden bg-transparent border-none flex items-center justify-center p-4 hidden transition-opacity duration-200 opacity-0 pointer-events-none">
      <!-- Backdrop overlay -->
      <div class="absolute inset-0 bg-black/60 backdrop-blur-xs"></div>
      
      <!-- Command modal body -->
      <div class="relative bg-white dark:bg-neutral-950 w-full max-w-lg rounded-2xl border border-neutral-300 dark:border-neutral-800 shadow-2xl flex flex-col overflow-hidden max-h-[85vh]">
        <!-- Search bar top row -->
        <div class="flex items-center gap-3 px-4 py-3 border-b border-neutral-200 dark:border-neutral-900 bg-neutral-50 dark:bg-neutral-900/30">
          <svg class="w-4 h-4 text-neutral-400" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
          <input
            id="command-search-input"
            type="text"
            autofocus
            placeholder="Modul suchen oder Aktion ausführen..."
            class="flex-1 bg-transparent border-none text-sm text-neutral-900 dark:text-white placeholder-neutral-400 focus:outline-none focus:ring-0 p-0"
          />
          <kbd class="hidden sm:inline-block px-1.5 py-0.5 text-[9px] font-mono rounded bg-neutral-200 dark:bg-neutral-800 text-neutral-500 border border-neutral-300 dark:border-neutral-700">ESC</kbd>
        </div>

        <!-- Options lists -->
        <div id="command-options-list" class="flex-1 overflow-y-auto p-2.5 max-h-[400px]">
          
          <div class="text-[9px] font-mono text-neutral-400 uppercase tracking-widest px-3 py-1 mb-1 block">Navigation</div>
          
          <!-- Option Row 1 -->
          <button class="cmd-option-row w-full text-left px-3 py-2 rounded-lg flex items-center justify-between hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer group" data-action="scroll-analyzer" data-match="Speed Analyzer Auditor Performance">
            <div class="flex items-center gap-3">
              <svg class="w-4 h-4 text-neutral-400 group-hover:text-brand-accent transition-colors shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10"></circle>
                <polyline points="12 6 12 12 16 14"></polyline>
              </svg>
              <div class="flex flex-col">
                <span class="text-xs font-bold text-neutral-850 dark:text-neutral-200 font-sans">Speed-Auditor öffnen</span>
                <span class="text-[9.5px] text-neutral-400">Interaktiven PageSpeed Core Web Vitals Simulator anzeigen</span>
              </div>
            </div>
            <span class="text-[9px] font-mono text-neutral-400 bg-neutral-100 dark:bg-neutral-900 px-1.5 py-0.5 rounded border border-neutral-200/40 dark:border-neutral-800/40 shrink-0">Navigieren</span>
          </button>

          <!-- Option Row 2 -->
          <button class="cmd-option-row w-full text-left px-3 py-2 rounded-lg flex items-center justify-between hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer group mt-1" data-action="scroll-projects" data-match="Projekte Case Studies Fallstudien WordPress Shop">
            <div class="flex items-center gap-3">
              <svg class="w-4 h-4 text-neutral-400 group-hover:text-brand-accent transition-colors shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <rect x="2" y="2" width="20" height="20" rx="2" ry="2"></rect>
                <rect x="9" y="9" width="6" height="6"></rect>
              </svg>
              <div class="flex flex-col">
                <span class="text-xs font-bold text-neutral-850 dark:text-neutral-200 font-sans">Fallstudien sichten</span>
                <span class="text-[9.5px] text-neutral-400 font-mono">WordPress, Woo &amp; Shopify Case-Listings aufrufen</span>
              </div>
            </div>
            <span class="text-[9px] font-mono text-neutral-400 bg-neutral-100 dark:bg-neutral-900 px-1.5 py-0.5 rounded border border-neutral-200/40 dark:border-neutral-800/40 shrink-0">Navigieren</span>
          </button>

          <!-- Option Row 3 -->
          <button class="cmd-option-row w-full text-left px-3 py-2 rounded-lg flex items-center justify-between hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer group mt-1" data-action="scroll-timeline" data-match="Timeline Lebenslauf Werdegang Erfahrung">
            <div class="flex items-center gap-3">
              <svg class="w-4 h-4 text-neutral-400 group-hover:text-brand-accent transition-colors shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
              <div class="flex flex-col">
                <span class="text-xs font-bold text-neutral-850 dark:text-neutral-200 font-sans">Erfahrung im Detail</span>
                <span class="text-[9.5px] text-neutral-400">Werdegang &amp; Factual accordion proof-of-work einblenden</span>
              </div>
            </div>
            <span class="text-[9px] font-mono text-neutral-400 bg-neutral-100 dark:bg-neutral-900 px-1.5 py-0.5 rounded border border-neutral-200/40 dark:border-neutral-800/40 shrink-0">Navigieren</span>
          </button>

          <!-- Option Row 4 -->
          <button class="cmd-option-row w-full text-left px-3 py-2 rounded-lg flex items-center justify-between hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer group mt-1" data-action="scroll-contact" data-match="Kontakt Brief Mail Formular Telefon Recruiting">
            <div class="flex items-center gap-3">
              <svg class="w-4 h-4 text-neutral-400 group-hover:text-brand-accent transition-colors shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
              </svg>
              <div class="flex flex-col">
                <span class="text-xs font-bold text-neutral-850 dark:text-neutral-200 font-sans">Kontakt aufnehmen</span>
                <span class="text-[9.5px] text-neutral-400">Recruiting-Inquiries Formular direkt fokussieren</span>
              </div>
            </div>
            <span class="text-[9px] font-mono text-neutral-400 bg-neutral-100 dark:bg-neutral-900 px-1.5 py-0.5 rounded border border-neutral-200/40 dark:border-neutral-800/40 shrink-0">Fokus</span>
          </button>

          <div class="text-[9px] font-mono text-neutral-400 uppercase tracking-widest px-3 py-1 mt-4 mb-1 block">Aktionen</div>

          <!-- Option Row 5 -->
          <button class="cmd-option-row w-full text-left px-3 py-2 rounded-lg flex items-center justify-between hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer group" data-action="download-cv" data-match="Lebenslauf CV Download jspdf PDF">
            <div class="flex items-center gap-3">
              <svg class="w-4 h-4 text-neutral-400 group-hover:text-brand-accent transition-colors shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
              </svg>
              <div class="flex flex-col">
                <span class="text-xs font-bold text-neutral-850 dark:text-neutral-200 font-sans">CV Downloaden (PDF)</span>
                <span class="text-[9.5px] text-neutral-400">Lebenslauf als 3-seitige DIN-A4 Datei per jspdf generieren</span>
              </div>
            </div>
            <span class="text-[9px] font-mono text-emerald-500 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/15 shrink-0">Download</span>
          </button>

          <!-- Option Row 6 -->
          <button class="cmd-option-row w-full text-left px-3 py-2 rounded-lg flex items-center justify-between hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer group mt-1" data-action="toggle-dark" data-match="Theme Dark Light Farbmodus Farbschema">
            <div class="flex items-center gap-3">
              <svg class="w-4 h-4 text-neutral-400 group-hover:text-brand-accent transition-colors shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
              </svg>
              <div class="flex flex-col">
                <span class="text-xs font-bold text-neutral-850 dark:text-neutral-200 font-sans">Farbschema umschalten</span>
                <span class="text-[9.5px] text-neutral-400">Direkt zwischen Light- und Darkmode her wechseln</span>
              </div>
            </div>
            <span class="text-[9px] font-mono text-neutral-400 bg-neutral-100 dark:bg-neutral-900 px-1.5 py-0.5 rounded border border-neutral-200/40 dark:border-neutral-800/40 shrink-0">Umschalten</span>
          </button>

          <!-- Option Row 7 -->
          <button class="cmd-option-row w-full text-left px-3 py-2 rounded-lg flex items-center justify-between hover:bg-neutral-100 dark:hover:bg-neutral-900 transition-colors cursor-pointer group mt-1" data-action="open-engine" data-match="Live Layout Konfiguration Schriftart Font Spacing">
            <div class="flex items-center gap-3">
              <svg class="w-4 h-4 text-neutral-400 group-hover:text-brand-accent transition-colors shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <line x1="4" y1="21" x2="4" y2="14"></line>
                <line x1="4" y1="10" x2="4" y2="3"></line>
              </svg>
              <div class="flex flex-col">
                <span class="text-xs font-bold text-neutral-850 dark:text-neutral-200 font-sans">Live-Layout Engine</span>
                <span class="text-[9.5px] text-neutral-400">Schriftarten, Farben und Abstandsmaße anpassen</span>
              </div>
            </div>
            <span class="text-[9px] font-mono text-neutral-400 bg-neutral-100 dark:bg-neutral-900 px-1.5 py-0.5 rounded border border-neutral-200/40 dark:border-neutral-800/40 shrink-0">Panel</span>
          </button>

        </div>

        <!-- Footer instructions row inside command modal -->
        <div class="px-4 py-2 border-t border-neutral-200 dark:border-neutral-900 flex items-center justify-between text-[9px] text-neutral-600 dark:text-neutral-400 font-mono">
          <span>Drücken Sie eine Option zum Ausführen.</span>
          <button id="btn-close-command-menu" class="hover:underline hover:text-neutral-950 dark:hover:text-white cursor-pointer select-none">Menü Schließen</button>
        </div>

      </div>
    </div>

    <!-- Dynamic Hidden virtual CV down-trigger inside DOM tree -->
    <button id="btn-download-cv" class="cv-download-trigger hidden"></button>

    <?php wp_footer(); // ← WP-MIGRATION: Core WordPress script hooks ?>
  </body>
</html>
