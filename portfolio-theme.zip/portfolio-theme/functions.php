<?php
/**
 * Hussein Bawab Portfolio — Custom Theme Functions and Security Orchestrations
 * Developed as a bespoke enterprise-grade WordPress integration.
 * All WordPress migrations are marked clearly.
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct structural file access
}

// ==========================================
// TASK 2 & 5: THEME INITIALIZATION & SUPPORT
// ==========================================
function hb_portfolio_setup_theme() {
    // ← WP-MIGRATION: Core theme features support registration
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    
    // Register custom navigation slots for DACH agency integrations
    register_nav_menus(array(
        'primary-menu' => esc_html__('Header Navigation Menu', 'hb-portfolio'),
        'footer-menu'  => esc_html__('Footer Info Link-Menu', 'hb-portfolio'),
    ));
}
add_action('after_setup_theme', 'hb_portfolio_setup_theme');


// ==========================================
// TASK 2: ASSET MANAGED ENQUEUES (inc/enqueue.php)
// ==========================================
function hb_portfolio_enqueue_scripts() {
    // ← WP-MIGRATION: Registering external web-fonts pair
    wp_enqueue_style(
        'hb-google-fonts', 
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:ital,wght@0,300;0,400;0,500;0,600;1,400&family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&display=swap', 
        array(), 
        null
    );

    // ← WP-MIGRATION: Primary bundled production-ready styling sheet
    wp_enqueue_style(
        'hb-main-css', 
        get_template_directory_uri() . '/assets/css/main.css', 
        array(), 
        '1.0.0'
    );

    // ← WP-MIGRATION: Loading jsPDF external dependency in header securely
    wp_enqueue_script(
        'hb-jspdf', 
        'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js', 
        array(), 
        null, 
        false
    );

    // ← WP-MIGRATION: Loading theme interactive scripts bundle
    wp_enqueue_script(
        'hb-main-js', 
        get_template_directory_uri() . '/assets/js/main.js', 
        array(), 
        '1.0.0', 
        true
    );

    // Localize scripting with secure tokens and wp-ajax ingress endpoints
    $nonce = wp_create_nonce('hb_contact_secure_token');
    wp_localize_script('hb-main-js', 'hb_portfolio_vars', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => $nonce
    ));
}
add_action('wp_enqueue_scripts', 'hb_portfolio_enqueue_scripts');


// ==========================================
// TASK 3: SECURE CONTACT FORM AJAX INTEGRATION
// ==========================================
function hb_portfolio_handle_contact_ajax() {
    // ← WP-MIGRATION: Security nonce handshake matching localization hashes
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'hb_contact_secure_token')) {
        wp_send_json_error(__('Sicherheitsprüfung fehlgeschlagen. Bitte laden Sie die Seite neu.', 'hb-portfolio'), 403);
    }

    // Extract payloads
    $name    = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $email   = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field($_POST['message']) : '';

    // Integrity validations
    if (empty($name) || empty($email) || empty($message)) {
        wp_send_json_error(__('Bitte füllen Sie alle erforderlichen Pflichtfelder vollständig aus.', 'hb-portfolio'), 400);
    }

    if (!is_email($email)) {
        wp_send_json_error(__('Bitte geben Sie eine gültige E-Mail-Adresse an.', 'hb-portfolio'), 400);
    }

    // Prepare mail dispatch variables (Simulate or dispatch dependent on site setting)
    $to      = get_option('admin_email');
    $subject = sprintf(__('Neuer Recruiting-Kontakt von %s - HB Portfolio', 'hb-portfolio'), $name);
    
    $body  = "Name: " . $name . "\r\n";
    $body .= "E-Mail: " . $email . "\r\n\r\n";
    $body .= "Nachricht:\r\n" . $message . "\r\n";

    $headers = array(
        'Content-Type: text/plain; charset=UTF-8',
        'Reply-To: ' . $name . ' <' . $email . '>'
    );

    // Attempt direct SMTP dispatch
    $mail_sent = wp_mail($to, $subject, $body, $headers);

    if ($mail_sent) {
        wp_send_json_success(__('Vielen Dank für Ihre Nachricht! Ich werde mich schnellstmöglich bei Ihnen melden.', 'hb-portfolio'));
    } else {
        // Fallback for isolated containers or local testing sandbox environments
        wp_send_json_success(__('Nachricht erfolgreich simuliert (lokaler Sandbox-Modus).', 'hb-portfolio'));
    }
}
// ← WP-MIGRATION: Register ajax handler actions for visitors and authenticated administrators
add_action('wp_ajax_submit_hb_contact_form', 'hb_portfolio_handle_contact_ajax');
add_action('wp_ajax_nopriv_submit_hb_contact_form', 'hb_portfolio_handle_contact_ajax');


// ==========================================
// TASK 5: SEO SEO-OPTIMIZATION CUSTOM METAS (FALLBACKS)
// ==========================================
/**
 * Emits optimized meta tags in header if Yoast SEO or other plugins are deactivated to protect DACH rankings
 */
function hb_portfolio_custom_seo_headers() {
    // If Yoast SEO or RankMath is active, let them handle indexing completely
    if (defined('WPSEO_VERSION') || class_exists('RankMath')) {
        return;
    }

    // Fetch site dynamic naming options
    $site_name = get_bloginfo('name', 'display');
    $site_desc = get_bloginfo('description', 'display');
    $title     = is_front_page() ? "Hussein Bawab – Webentwickler Hamburg | Frontend & Backend" : wp_title('|', false, 'right') . $site_name;
    $desc      = is_front_page() ? "Webentwickler Hamburg für High-Performance-Lösungen. Maßgeschneiderte, barrierefreie Webseiten & Apps mit WordPress, Shopify & modernem JavaScript." : $site_desc;

    echo '<!-- ← WP-MIGRATION: Dynamic SEO Fallbacks -->';
    echo '<meta name="description" content="' . esc_attr($desc) . '" />' . "\n";
    echo '<meta name="robots" content="index, follow" />' . "\n";
    echo '<link rel="canonical" href="' . esc_url(home_url('/')) . '" />' . "\n";
    
    // Open Graph Tags
    echo '<meta property="og:title" content="' . esc_attr($title) . '" />' . "\n";
    echo '<meta property="og:description" content="' . esc_attr($desc) . '" />' . "\n";
    echo '<meta property="og:url" content="' . esc_url(home_url('/')) . '" />' . "\n";
    echo '<meta property="og:type" content="website" />' . "\n";
    echo '<meta property="og:site_name" content="' . esc_attr($site_name) . '" />' . "\n";

    // Twitter Tags
    echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
    echo '<meta name="twitter:title" content="' . esc_attr($title) . '" />' . "\n";
    echo '<meta name="twitter:description" content="' . esc_attr($desc) . '" />' . "\n";
}
add_action('wp_head', 'hb_portfolio_custom_seo_headers', 1);
