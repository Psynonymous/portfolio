/**
 * Hussein Bawab Portfolio - Core Theme JavaScript Engine
 * Feature-complete migration of all interactive capabilities to WordPress of:
 * - Live Timezone Clock
 * - Site-wide CSS Variables Custom Layout Engine
 * - Core Web Vitals PageSpeed Simulator
 * - Filterable Interactive Case Studies
 * - Comparative Code Inspector Workspace (Sauber vs. Slop)
 * - Accordion Proof-of-Work Experience Timeline
 * - WordPress secure AJAX Contact Form submission with fallback
 * - Modern Keyboard Command Centered Menu (Ctrl + K)
 * - jsPDF-based 3-Page CV Document Generator
 * - Hamburger Mobile Menu controllers
 * - LocalStorage state caches & smooth scroll scrollings
 *
 * All WordPress integrations are explicitly marked.
 */

// Global state cache objects
let selectedInspectorProject = null;
let showLazyAlternativeCode = false;
let activeStoryIdx = null;

// Safe Storage Helper to handle sandboxed environment contexts
const safeStorage = {
  getItem(key) {
    try {
      return localStorage.getItem(key);
    } catch (e) {
      return null;
    }
  },
  setItem(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      // ignore silently
    }
  }
};

// Site-wide default or cached styling configs
const currentLayoutState = {
  accent: safeStorage.getItem("bawab-layout-accent") || "cyan",
  font: safeStorage.getItem("bawab-layout-font") || "serif",
  density: safeStorage.getItem("bawab-layout-density") || "cozy",
  size: safeStorage.getItem("bawab-layout-size") || "medium",
  darkTheme: safeStorage.getItem("bawab-layout-dark") === null ? true : safeStorage.getItem("bawab-layout-dark") === "true",
  highContrast: safeStorage.getItem("bawab-layout-contrast") === "true"
};

// Web Vitals Engine settings
const activeOptimizations = {
  images: false,
  scripts: false,
  fonts: false,
  css: false
};

// Database mock objects: Project case studies
const PROJECTS = [
  {
    id: "clean-wp-hooks",
    title: "Sicherheit & Hook-Performance",
    category: "WordPress",
    impact: "Unbreakable Security",
    description: "Implementierung einer gehärteten Content-Security-Policy (CSP) gekoppelt an einen hochperformanten, asynchronen Asset-Loader für ein internationales Konzern-Intranet.",
    challenges: [
      "Strikte Unterbindung von XSS & Code-Injections über Drittanbieter-Plugins",
      "Maximierung der Performance durch Verhinderung von Parser-blockierenden Scripts im Header",
      "Dynamische Filterung von sensiblen Backend-Daten zur DSGVO-konformen Auditierung"
    ],
    tech: ["Security Engine", "DSGVO Audit", "Performance Loader"],
    codeLanguage: "php",
    codeSnippet: `<?php
/**
 * Security Handshake & Custom Asset Orchestration Engine
 * ─── WP-STANDARDS CONFORMING & ASYNC RESOLVED ───
 */
namespace HB\\SecurityEngine;

if (!defined('ABSPATH')) exit; // Prevent direct structural files inclusion

class AssetOptimizer {
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'safelyEnqueueAssets'), 99);
        add_filter('script_loader_tag', array($this, 'resolveAsyncDefer'), 10, 3);
        add_action('send_headers', array($this, 'applyCspHeaders'));
    }

    public function safelyEnqueueAssets(): void {
        // Enqueue verified vendor scripts with explicit versions and signature hashes
        wp_enqueue_script(
            'hb-core-analytics', 
            get_template_directory_uri() . '/assets/vendor/opt-tracking.js', 
            array(), 
            '1.4.2', 
            true
        );
    }

    public function resolveAsyncDefer(string $tag, string $handle, string $src): string {
        // Mark specific tracking and background analytics handlers as deferred asynchronously
        if ('hb-core-analytics' === $handle) {
            return sprintf("<script src='%s' async defer crossorigin='anonymous'></script>\\n", esc_url($src));
        }
        return $tag;
    }

    public function applyCspHeaders(): void {
        if (!is_admin()) {
            header("Content-Security-Policy: default-src 'self' https://fonts.googleapis.com; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net;");
            header("X-Frame-Options: SAMEORIGIN");
            header("X-Content-Type-Options: nosniff");
            header("X-XSS-Protection: 1; mode=block");
        }
    }
}

new AssetOptimizer();`,
    rawStory: ""
  },
  {
    id: "woo-db-indices",
    title: "SQL-Querier & Custom Indices",
    category: "WooCommerce",
    impact: "+320% Checkout-Speed",
    description: "Skalierung eines WooCommerce-Setups auf über 180.000 aktive Produkte durch Beseitigung schwerer Datenbank-Inkompatibilitäten und Erstellung optimierter WP-DB Query-Strukturen.",
    challenges: [
      "Extrem langsame Abfragen beim Laden verschachtelter Produktvariationen im Ajax-Dropdown",
      "Datenbank-Aufblähung durch massenhafte, unstrukturierte transiente Options und Session-Müll",
      "Beseitigung von Blocking I/O Locks während zeitgleicher Kundenbestellungen (Flash Sale Events)"
    ],
    tech: ["WPDB Queries", "Woo Indexer", "Query Optimizers"],
    codeLanguage: "php",
    codeSnippet: `<?php
/**
 * High-Scale WooCommerce custom indexer query handler 
 * ─── BYPASSING HEAVY WP_QUERY BLOAT FOR RAZOR SHARP FETCHES ───
 */
namespace HB\\WooCustomEngine;

if (!defined('ABSPATH')) exit;

class CatalogIndexer {
    private \\wpdb $wpdb;

    public function __construct() {
        global $wpdb;
        this->wpdb = $wpdb;
        add_filter('posts_clauses', array($this, 'injectCustomQueryIndices'), 10, 2);
    }

    public function injectCustomQueryIndices(array $clauses, \\WP_Query $query): array {
        // Apply optimized database index bypasses to meta queries only when targeted catalog load is active
        if ($query->get('hb_catalog_optimized_fetch') && is_search()) {
            $clauses['join'] .= " FORCE INDEX (meta_key_value) "; // ← WP-MIGRATION Force performance index bindings
        }
        return $clauses;
    }

    public function fetchDirectVariations(int $parentProductId): array {
        // Bypass heavy meta objects load completely and run a optimized direct DB tuple collection scan
        $sql = $this->wpdb->prepare("
            SELECT posts.ID, posts.post_title, meta.meta_value AS sku 
            FROM {$this->wpdb->posts} AS posts
            INNER JOIN {$this->wpdb->postmeta} AS meta ON (posts.ID = meta.post_id AND meta.meta_key = '_sku')
            WHERE posts.post_parent = %d 
              AND posts.post_type = 'product_variation' 
              AND posts.post_status = 'publish'
            ORDER BY posts.menu_order ASC
        ", $parentProductId);

        return $this->wpdb->get_results($sql, ARRAY_A);
    }
}
`,
    rawStory: ""
  },
  {
    id: "shopify-headless",
    title: "Headless Node Router Middleware",
    category: "Shopify",
    impact: "0.2s LCP Integration",
    description: "Entwicklung eines superschnellen Shopify Headless Storefront-Routers über eine hochgradig abgesicherte Node.js / Express Middleware für ein personalisiertes, dezentrales Einkaufserlebnis.",
    challenges: [
      "Latenz-Verschlechterung bei direkten Shopify GraphQL Storefront-API Client-Anfragen",
      "Erstellung sicherer OAuth Token-Rotations-Mechanismen zum Schutz sensibler Checkout-Daten",
      "Einbindung intelligenter und hochperformanter Edge-Caches zur Entlastung der Backend-Schnittstelle"
    ],
    tech: ["GraphQL Router", "Node Middleware", "Varnish Cache"],
    codeLanguage: "js",
    codeSnippet: `/**
 * Shopify Headless router middleware proxy server module code 
 * ─── ASYNC RESOLVED, NON-BLOCKING EDGE HANDLERS ───
 */
const express = require('express');
const router = express.Router();
const dns = require('dns').promises;

// Secure Token Rotator and Shopify GraphQL Ingress API Dispatchers
router.post('/api/storefront/cart-ingress', async (req, res, next) => {
  const { cartId, lineItems } = req.body;
  
  if (!cartId || !Array.isArray(lineItems)) {
    return res.status(400).json({ error: 'Payload validation parameters failed' });
  }

  try {
    const rawResponse = await fetch(\`https://\${process.env.SHOPIFY_STORE_DOMAIN}/api/2026-04/graphql.json\`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Shopify-Storefront-Access-Token': process.env.SHOPIFY_STOREFRONT_TOKEN,
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        query: \`
          mutation cartLinesAdd($cartId: ID!, $lines: [BaseCartLineItemInput!]!) {
            cartLinesAdd(cartId: $cartId, lines: $lines) {
              cart {
                id
                checkoutUrl
              }
            }
          }
        \`,
        variables: { cartId, lines: lineItems }
      })
    });

    const parsedData = await rawResponse.json();
    return res.status(200).json(parsedData);

  } catch (error) {
    next(error); // Route errors safely to localized error stack handlers without leaking internal parameters
  }
});

module.exports = router;`,
    rawStory: ""
  }
];

// Alternate "slop" code alternatives database to compare in workspace
const SLOP_RECIPES = {
  "clean-wp-hooks": `<?php
/**
 * Sogenanntes 'Copypaste-Script' aus zwielichtigen Foren.
 * ─── ACHTUNG: PARSER-BLOCKIERSCHUTZ AUSGESCHALTET & HOCHGRADIG UNSICHER ───
 */

// Keine Prüfung auf ABSPATH. Hacker können Datei direkt aufrufen!

// Globale Styles und Javascripts einfach ohne Hooks in wp_head geprintet
function dirty_header_printer() {
    // 1. Gewaltiger DNS-Lookup auf Tracker und unoptimierte Bibliotheken
    echo '<script src="https://extremely-slow-untrusted-analytics-cdn.com/tracker.js"></script>';
    
    // 2. Inline Scripts infiltrieren und ruinieren das Caching des Browsers komplett
    echo '<script>
        alert("Cookie-Zustimmung erhalten!");
        // Undichter, global sichtbarer Variablensalat im Window Scope
        window.bawabIsAwesome = true;
    </script>';

    // 3. Unoptimierte CSS-Dateien blockieren die gesamte Seiten-Anzeige (Render Blocking)
    echo '<link rel="stylesheet" href="http://unsecured-http.com/massive-heavy-theme-framework.css">';
}

add_action('wp_head', 'dirty_header_printer'); // Unkontrollierter Aufruf direkt im Header
`,
  "woo-db-indices": `<?php
/**
 * Schreckliche, nicht-optimierte SQL Killer-Abfrage
 * ─── WARNUNG: PRODUZIERT DATABASE CRASHES & SQL-INJECTIONS unter Auslastung ───
 */

function get_woo_variations_slop_way() {
    global $wpdb;
    
    // 1. DIREKTE EINBETTUNG VON GET-PARAMETERN (Hacker-Paradies: SQL INJECTION SCHWACHSTELLE!)
    $unsafe_id = $_GET['parent_id']; 

    // 2. EXTREM TEURE NESTED TUPLE-METADATENSCHLEIFE UNTERSTÜTZT KEINEN INDEX
    // Ruft für JEDES Produkt im gesamten Shop Abfragen in verschachtelten Joins auf
    $query = "SELECT * FROM " . $wpdb->prefix . "posts AS p 
              LEFT JOIN " . $wpdb->prefix . "postmeta AS m ON p.ID = m.post_id
              WHERE p.post_parent = " . $unsafe_id . " 
              AND p.post_type = 'product_variation'"; 

    // Verursacht CPU-Auslastung von 100% bei gleichzeitigen Besuchern!
    return $wpdb->get_results($query); 
}
`,
  "shopify-headless": `/**
 * Schlechter, ungesicherter Node.js Router-Verschnitt
 * ─── CRASHED DEN SERVER BEI JEDEM FEHLERHAFTEN NETZWERKDISPATCH ───
 */
const express = require('express');
const router = express.Router();

router.post('/api/storefront/cart-ingress', (req, res) => {
  // 1. Keine Parameter-Prüfungen! Bei fehlendem Payload stürzt die App sofort ab (Memory Leak)
  const cartId = req.body.cartId;
  const lineItems = req.body.lineItems;

  // 2. Unverschlüsselte API Token in den Code hartcodiert (Sicherheitskatastrophe!)
  const accessToken = 'shpat_secret_token_1a2b3c4d5e6f_strictly_do_not_steal_it';

  // 3. Kein error Handling. Server bricht bei Timeout ab (502 Bad Gateway)
  fetch('https://active-storefront.myshopify.com/api/2026-04/graphql.json', {
    method: 'POST',
    headers: {
      'X-Shopify-Storefront-Access-Token': accessToken,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
       query: 'mutation cartLinesAdd($cartId: ID!, $lines: [BaseCartLineItemInput!]!) { ... }',
       variables: { cartId: cartId, lines: lineItems }
    })
  }).then(resp => resp.json()).then(data => {
    // 4. Sendet ungefiltertes JSON zurück an Frontend (Sicherheits-Leck!)
    res.send(data);
  });
});
`
};

// Database mock objects: CV history milestones
const TIMELINE = [
  {
    date: "10/2021 – Aktuell",
    role: "Senior Full-Stack Webentwickler",
    company: "Hussein Bawab – IT & Web-Engineering, Berlin / Hamburg (Remote)",
    description: "Konzeptionierung und Entwicklung performanter Enterprise-Webarchitekturen für Agenturen, mittelständische Unternehmen und DACH-Marken.",
    techUsed: ["React / Next.js", "Node & Express", "WooCommerce", "WordPress Core Engine API"],
    realStory: "Praxisnahe System-Härtung im DACH-E-Commerce. Erfolgreiche Restrukturierung monolithischer Shopsysteme hin zu modularen Architekturen. Maßgebliche Reduzierung von LCP-Werten und Serverkosten unter Beibehaltung aller Kernfunktionalitäten."
  },
  {
    date: "04/2020 – 09/2021",
    role: "Full-Stack Webentwickler",
    company: "Pirelli Deutschland GmbH, Berlin / Hamburg",
    description: "Ausarbeitung maßgeschneiderter Web-Schnittstellen und technischer Tools im B2B-Umfeld zur Digitalisierung etablierter Vertriebswege.",
    techUsed: ["Vanilla Svelte Engine", "MySQL DB Clusters", "REST API Architectures"],
    realStory: "Integration komplexer, echtzeitfähiger Reifenauswahl-Datenbänke. Entwicklung hocheffizienter Routing-Algorithmen zur schnellen Ermittlung regionaler Lieferwege unter Last."
  },
  {
    date: "04/2018 – 03/2020",
    role: "Full-Stack Webentwickler",
    company: "E-Commerce-Agentur Active-Storefront, Hamburg",
    description: "Technische Umsetzung, Performance-Auditing und Internationalisierung anspruchsvoller Shopsysteme für wachsende Modemarken.",
    techUsed: ["Shopify Headless", "PHP Custom Extensions", "SCSS Styling Systems"],
    realStory: "Agentur-Alltag mit harten Milestones. Erfolgreicher Launch von 14 mehrsprachigen E-Commerce-Plattformen. Etablierung eines einheitlichen Boilerplates für Web-Performance."
  }
];

// DOMContentLoaded Core entry logic
document.addEventListener("DOMContentLoaded", () => {
  // Select initial inspector item default
  selectedInspectorProject = PROJECTS[0];

  // Run modules initialization
  initLiveClock();
  initThemeEngine();
  initSpeedSimulator();
  renderCaseStudies("All");
  initCaseStudiesFilters();
  renderCodeInspectorSidebar();
  renderCodeInspectorWorkspace();
  renderTimelineChronology();
  initRecruitingContactForm();
  setupAnchorLinksSmoothScroll();
  initMobileHamburgerDropdown();

  // Load keyboard overlay menu binds
  initCommandMenu();

  // Load CV Downloader binds
  initCvDownloader();
});

// 1. TIMEZONE CLOCK UPDATES
function initLiveClock() {
  const clockEl = document.getElementById("hamburg-clock");
  if (!clockEl) return;

  const updateClock = () => {
    try {
      const options = {
        timeZone: "Europe/Berlin",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false
      };
      const formatter = new Intl.DateTimeFormat("de-DE", options);
      clockEl.textContent = formatter.format(new Date());
    } catch (e) {
      const d = new Date();
      clockEl.textContent = d.toTimeString().split(" ")[0];
    }
  };
  updateClock();
  setInterval(updateClock, 1000);
}

// 2. LIVE DESIGN CUSTOMIZER ENGINE
function initThemeEngine() {
  // Initial sync from cached options state onto HTML document root
  applyAccentState(currentLayoutState.accent);
  applyFontState(currentLayoutState.font);
  applyDensityState(currentLayoutState.density);
  applySizeState(currentLayoutState.size);
  applyCoreThemeModeState(currentLayoutState.darkTheme);
  applyHighContrastState(currentLayoutState.highContrast);

  // Sync Checkbox accessibility values if selector exists
  const contrastToggle = document.getElementById("toggle-high-contrast");
  if (contrastToggle) {
    contrastToggle.checked = currentLayoutState.highContrast;
    contrastToggle.addEventListener("change", (e) => {
      const isChecked = e.target.checked;
      currentLayoutState.highContrast = isChecked;
      safeStorage.setItem("bawab-layout-contrast", isChecked ? "true" : "false");
      applyHighContrastState(isChecked);
    });
  }

  // Accent pickers clicks
  const pickerButtons = document.querySelectorAll(".clr-picker-btn");
  pickerButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const selectedClr = btn.getAttribute("data-color");
      currentLayoutState.accent = selectedClr;
      safeStorage.setItem("bawab-layout-accent", selectedClr);
      applyAccentState(selectedClr);
    });
  });

  // Font selectors clicks
  const fontButtons = document.querySelectorAll(".font-selector-btn");
  fontButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const selectedFont = btn.getAttribute("data-font");
      currentLayoutState.font = selectedFont;
      safeStorage.setItem("bawab-layout-font", selectedFont);
      applyFontState(selectedFont);
    });
  });

  // Size selectors clicks
  const sizeButtons = document.querySelectorAll(".size-selector-btn");
  sizeButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const selectedSize = btn.getAttribute("data-size");
      currentLayoutState.size = selectedSize;
      safeStorage.setItem("bawab-layout-size", selectedSize);
      applySizeState(selectedSize);
    });
  });

  // Spacing Density triggers clicks
  const densityButtons = document.querySelectorAll(".density-selector-btn");
  densityButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const selectedDensity = btn.getAttribute("data-density");
      currentLayoutState.density = selectedDensity;
      safeStorage.setItem("bawab-layout-density", selectedDensity);
      applyDensityState(selectedDensity);
    });
  });

  // Standard reset Layout values button
  const resetBtn = document.getElementById("btn-reset-layout");
  if (resetBtn) {
    resetBtn.addEventListener("click", () => {
      currentLayoutState.accent = "cyan";
      currentLayoutState.font = "serif";
      currentLayoutState.density = "cozy";
      currentLayoutState.size = "medium";
      currentLayoutState.highContrast = false;

      safeStorage.setItem("bawab-layout-accent", "cyan");
      safeStorage.setItem("bawab-layout-font", "serif");
      safeStorage.setItem("bawab-layout-density", "cozy");
      safeStorage.setItem("bawab-layout-size", "medium");
      safeStorage.setItem("bawab-layout-contrast", "false");

      if (contrastToggle) contrastToggle.checked = false;

      applyAccentState("cyan");
      applyFontState("serif");
      applyDensityState("cozy");
      applySizeState("medium");
      applyHighContrastState(false);
    });
  }

  // Header quick Theme toggle buttons triggers
  const themeToggle = document.getElementById("theme-toggle-btn");
  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      currentLayoutState.darkTheme = !currentLayoutState.darkTheme;
      safeStorage.setItem("bawab-layout-dark", currentLayoutState.darkTheme);
      applyCoreThemeModeState(currentLayoutState.darkTheme);
    });
  }

  // Floating design settings popup controller triggers
  const toggleBtn = document.getElementById("btn-toggle-layout-engine");
  const popover = document.getElementById("layout-engine-popover");

  if (toggleBtn && popover) {
    const showPopover = () => {
      popover.classList.remove("hidden");
      setTimeout(() => {
        popover.classList.remove("opacity-0", "scale-95", "pointer-events-none");
        popover.classList.add("opacity-100", "scale-100");
      }, 10);
    };

    const hidePopover = () => {
      popover.classList.remove("opacity-100", "scale-100");
      popover.classList.add("opacity-0", "scale-95", "pointer-events-none");
      setTimeout(() => {
        if (popover.classList.contains("opacity-0")) {
          popover.classList.add("hidden");
        }
      }, 200);
    };

    toggleBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const isHidden = popover.classList.contains("hidden");
      if (isHidden) {
        showPopover();
      } else {
        hidePopover();
      }
    });

    document.addEventListener("click", (e) => {
      if (!popover.classList.contains("hidden")) {
        const isClickInsidePopover = popover.contains(e.target);
        const isClickOnToggleBtn = toggleBtn.contains(e.target);
        const isClickOnThemeToggle = e.target.closest("#theme-toggle-btn") || e.target.closest("#theme-toggle");

        if (!isClickInsidePopover && !isClickOnToggleBtn && !isClickOnThemeToggle) {
          hidePopover();
        }
      }
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && !popover.classList.contains("hidden")) {
        hidePopover();
      }
    });
  }
}

// Accent values mappings
function applyAccentState(color) {
  const root = document.documentElement;
  let hexCode = "#06b6d4";
  let rgbCode = "6, 182, 212";

  if (color === "purple") {
    hexCode = "#8b5cf6";
    rgbCode = "139, 92, 246";
  } else if (color === "amber") {
    hexCode = "#f59e0b";
    rgbCode = "245, 158, 11";
  } else if (color === "rose") {
    hexCode = "#f43f5e";
    rgbCode = "244, 63, 94";
  }

  root.style.setProperty("--brand-accent", hexCode);
  root.style.setProperty("--brand-accent-rgb", rgbCode);

  const pickerButtons = document.querySelectorAll(".clr-picker-btn");
  pickerButtons.forEach(btn => {
    const clrName = btn.getAttribute("data-color");
    const checkIcon = btn.querySelector("svg");
    if (clrName === color) {
      btn.classList.add("ring-2", "ring-[#070708]", "dark:ring-white", "ring-offset-2", "ring-offset-[#070708]");
      if (checkIcon) checkIcon.classList.remove("hidden");
    } else {
      btn.classList.remove("ring-2", "ring-[#070708]", "dark:ring-white", "ring-offset-2", "ring-offset-[#070708]");
      if (checkIcon) checkIcon.classList.add("hidden");
    }
  });

  printActiveLayoutString();
}

// Active Font pair styles mappings
function applyFontState(fontStyle) {
  const root = document.documentElement;
  let fontValueHeader = "var(--font-sans)";
  let fontValueBody = "var(--font-sans)";

  if (fontStyle === "serif") {
    fontValueHeader = "var(--font-serif)";
    fontValueBody = "var(--font-sans)";
  } else if (fontStyle === "mono") {
    fontValueHeader = "var(--font-mono)";
    fontValueBody = "var(--font-mono)";
  }

  root.style.setProperty("--active-header-font", fontValueHeader);
  root.style.setProperty("--active-body-font", fontValueBody);

  const fontButtons = document.querySelectorAll(".font-selector-btn");
  fontButtons.forEach(btn => {
    const fontName = btn.getAttribute("data-font");
    if (fontName === fontStyle) {
      btn.className = "font-selector-btn py-1 px-1.5 rounded text-[10px] font-bold text-center uppercase cursor-pointer transition-all bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-xs flex items-center justify-center h-7 select-none leading-none";
    } else {
      btn.className = "font-selector-btn py-1 px-1.5 rounded text-[10px] font-semibold text-center uppercase cursor-pointer transition-all text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 flex items-center justify-center h-7 select-none leading-none";
    }
  });

  printActiveLayoutString();
}

// Layout densities toggling HTML root classes
function applyDensityState(densityChoice) {
  const root = document.documentElement;
  root.classList.remove("density-compact", "density-cozy", "density-relaxed");
  root.classList.add(`density-${densityChoice}`);

  const densityButtons = document.querySelectorAll(".density-selector-btn");
  densityButtons.forEach(btn => {
    const dName = btn.getAttribute("data-density");
    if (dName === densityChoice) {
      btn.className = "density-selector-btn py-1 px-1.5 rounded text-[10px] font-bold text-center uppercase cursor-pointer transition-all bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-xs flex items-center justify-center h-7 select-none leading-none";
    } else {
      btn.className = "density-selector-btn py-1 px-1.5 rounded text-[10px] font-semibold text-center uppercase cursor-pointer transition-all text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 flex items-center justify-center h-7 select-none leading-none";
    }
  });

  printActiveLayoutString();
}

// Font sizes toggling HTML root classes
function applySizeState(sizeChoice) {
  const root = document.documentElement;
  root.classList.remove("size-small", "size-medium", "size-large");
  root.classList.add(`size-${sizeChoice}`);

  const sizeButtons = document.querySelectorAll(".size-selector-btn");
  sizeButtons.forEach(btn => {
    const sName = btn.getAttribute("data-size");
    if (sName === sizeChoice) {
      btn.className = "size-selector-btn py-1 px-1.5 rounded text-[10px] font-bold text-center uppercase cursor-pointer transition-all bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-xs flex items-center justify-center h-7 select-none leading-none";
    } else {
      btn.className = "size-selector-btn py-1 px-1.5 rounded text-[10px] font-semibold text-center uppercase cursor-pointer transition-all text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200 flex items-center justify-center h-7 select-none leading-none";
    }
  });

  printActiveLayoutString();
}

// Apply core background colors mapping to custom body styles
function applyCoreThemeModeState(isDarkMode) {
  const root = document.documentElement;
  const iconDark = document.getElementById("theme-icon-dark");
  const iconLight = document.getElementById("theme-icon-light");
  const gridBg = document.getElementById("hero-grid-bg");

  if (isDarkMode) {
    root.classList.add("dark");
    document.body.classList.add("bg-[#070708]", "text-neutral-200");
    document.body.classList.remove("bg-white", "text-neutral-800");

    if (iconDark) iconDark.classList.add("hidden");
    if (iconLight) iconLight.classList.remove("hidden");
    if (gridBg) {
      gridBg.classList.add("editorial-grid");
      gridBg.classList.remove("editorial-grid-light");
    }
  } else {
    root.classList.remove("dark");
    document.body.classList.remove("bg-[#070708]", "text-neutral-200");
    document.body.classList.add("bg-white", "text-neutral-800");

    if (iconDark) iconDark.classList.remove("hidden");
    if (iconLight) iconLight.classList.add("hidden");
    if (gridBg) {
      gridBg.classList.remove("editorial-grid");
      gridBg.classList.add("editorial-grid-light");
    }
  }
}

// Contrast classes toggling on container elements
function applyHighContrastState(isContrastActive) {
  const root = document.documentElement;
  const contentRoot = document.getElementById("portfolio-content-root");
  if (isContrastActive) {
    root.classList.add("contrast-double");
    if (contentRoot) {
      contentRoot.classList.add("contrast-125");
    } else {
      document.body.classList.add("contrast-125");
    }
  } else {
    root.classList.remove("contrast-double");
    if (contentRoot) {
      contentRoot.classList.remove("contrast-125");
    }
    document.body.classList.remove("contrast-125");
  }
}

// Prints debug information layout specs at custom panel bottom section
function printActiveLayoutString() {
  const label = document.getElementById("debug-layout-string");
  if (!label) return;

  const fontName = currentLayoutState.font === "mono" ? "Monospace Brutalism" : currentLayoutState.font === "serif" ? "Editorial Serif" : "Neo-Grotesque";
  const densName = currentLayoutState.density === "compact" ? "Kompakt (Grid)" : currentLayoutState.density === "relaxed" ? "Luftig (Magazin)" : "Standard (Cozy)";
  const sizeName = currentLayoutState.size === "small" ? "Klein" : currentLayoutState.size === "large" ? "Groß" : "Mittel";

  label.textContent = `${fontName} / ${densName} / ${sizeName}`;
}

// 3. PAGE SPEED METRICS ENGINE SIMULATIONS
function initSpeedSimulator() {
  const cards = document.querySelectorAll(".opt-card-btn");
  cards.forEach(card => {
    card.addEventListener("click", () => {
      const optId = card.getAttribute("data-optid");
      let key = "images";
      if (optId === "scripts-opt") key = "scripts";
      else if (optId === "fonts-opt") key = "fonts";
      else if (optId === "css-opt") key = "css";

      activeOptimizations[key] = !activeOptimizations[key];
      applyOptimizationVisuals(card, activeOptimizations[key], key);
      recalculateSpeedMetrics();
    });
  });

  recalculateSpeedMetrics();
}

function applyOptimizationVisuals(cardNode, isActive, key) {
  const statusDot = cardNode.querySelector(".status-dot");
  const badgeStatus = cardNode.querySelector(".badge-status");
  const feedbackLabel = cardNode.querySelector(".feedback-label span");

  if (isActive) {
    cardNode.classList.add("border-brand-accent-soft", "bg-brand-accent-soft");
    cardNode.classList.remove("border-neutral-200", "dark:border-neutral-800", "hover:bg-neutral-50", "dark:hover:bg-neutral-900/40");

    if (statusDot) {
      statusDot.className = "status-dot w-2 h-2 rounded-full bg-brand-accent";
    }
    if (badgeStatus) {
      badgeStatus.className = "badge-status text-[9px] font-mono text-emerald-500 bg-emerald-500/10 px-1.5 py-0.2 rounded font-semibold uppercase";
      badgeStatus.textContent = "Aktiv";
    }

    if (key === "images") {
      feedbackLabel.className = "text-emerald-500 font-semibold";
      feedbackLabel.innerHTML = "✓ Bilder skaliert in AVIF/WebP, explizite AspectRatios gesetzt";
    } else if (key === "scripts") {
      feedbackLabel.className = "text-emerald-500 font-semibold";
      feedbackLabel.innerHTML = "✓ Tracking-Scripts asynchron verzögert geladen per Delay-Controller";
    } else if (key === "fonts") {
      feedbackLabel.className = "text-emerald-500 font-semibold";
      feedbackLabel.innerHTML = "✓ WOFF2 lokal selbstgehostet, font-display: swap erzwungen";
    } else if (key === "css") {
      feedbackLabel.className = "text-emerald-500 font-semibold";
      feedbackLabel.innerHTML = "✓ Kritisches CSS direkt inline, ungenutzter Elementor-Ballast eliminiert";
    }

  } else {
    cardNode.classList.remove("border-brand-accent-soft", "bg-brand-accent-soft");
    cardNode.classList.add("border-neutral-200", "dark:border-neutral-800", "hover:bg-neutral-50", "dark:hover:bg-neutral-900/40");

    if (statusDot) {
      statusDot.className = "status-dot w-2 h-2 rounded-full bg-neutral-300 dark:bg-neutral-600";
    }
    if (badgeStatus) {
      badgeStatus.className = "badge-status text-[9px] font-mono text-rose-500 bg-rose-500/10 px-1.5 py-0.2 rounded font-semibold uppercase";
      badgeStatus.textContent = "Inaktiv";
    }

    if (key === "images") {
      feedbackLabel.className = "text-neutral-600 dark:text-neutral-400";
      feedbackLabel.innerHTML = "✗ Schwere PNGs (4MB) ohne 'width/height' &amp; LazyLoad";
    } else if (key === "scripts") {
      feedbackLabel.className = "text-neutral-600 dark:text-neutral-400";
      feedbackLabel.innerHTML = "✗ Synchrone Einbindung im &lt;head&gt; (blockiert Parser)";
    } else if (key === "fonts") {
      feedbackLabel.className = "text-neutral-600 dark:text-neutral-400";
      feedbackLabel.innerHTML = "✗ Standard TTF ohne swap (verursacht unsichtbaren Text)";
    } else if (key === "css") {
      feedbackLabel.className = "text-neutral-600 dark:text-neutral-400";
      feedbackLabel.innerHTML = "✗ Megabyte-großes Framework-CSS (All-in-one)";
    }
  }
}

function recalculateSpeedMetrics() {
  let baseScore = 38;
  if (activeOptimizations.images) baseScore += 22;
  if (activeOptimizations.scripts) baseScore += 18;
  if (activeOptimizations.fonts) baseScore += 11;
  if (activeOptimizations.css) baseScore += 11;

  if (baseScore > 100) baseScore = 100;

  let lcpSec = 8.80;
  if (activeOptimizations.images) lcpSec -= 3.4;
  if (activeOptimizations.scripts) lcpSec -= 2.5;
  if (activeOptimizations.fonts) lcpSec -= 1.1;
  if (activeOptimizations.css) lcpSec -= 1.8;
  if (lcpSec < 0.60) lcpSec = 0.60;

  let inpMs = 210;
  if (activeOptimizations.scripts) inpMs -= 140;
  if (inpMs < 70) inpMs = 70;

  let clsInd = 0.42;
  if (activeOptimizations.images) clsInd -= 0.28;
  if (activeOptimizations.fonts) clsInd -= 0.11;
  if (activeOptimizations.scripts) clsInd -= 0.03;
  if (clsInd < 0.00) clsInd = 0.00;

  const scoreText = document.getElementById("score-text-val");
  const fillCircle = document.getElementById("gauge-fill-circle");

  if (scoreText) scoreText.textContent = baseScore;

  if (fillCircle) {
    const offset = 251.2 * (1 - baseScore / 100);
    fillCircle.style.strokeDashoffset = offset;

    fillCircle.classList.remove("stroke-rose-500", "stroke-amber-500", "stroke-emerald-500");
    scoreText.classList.remove("text-rose-500", "text-amber-500", "text-emerald-500");

    if (baseScore < 50) {
      fillCircle.classList.add("stroke-rose-500");
      scoreText.classList.add("text-rose-500");
    } else if (baseScore >= 50 && baseScore < 90) {
      fillCircle.classList.add("stroke-amber-500");
      scoreText.classList.add("text-amber-500");
    } else {
      fillCircle.classList.add("stroke-emerald-500");
      scoreText.classList.add("text-emerald-500");
    }
  }

  const lcpText = document.getElementById("metric-lcp-val");
  const lcpBadge = document.getElementById("metric-lcp-badge");
  if (lcpText && lcpBadge) {
    lcpText.textContent = `${lcpSec.toFixed(2)}s`;
    lcpBadge.className = "text-[10px] px-2 py-0.5 rounded font-mono " +
      (lcpSec > 2.5 ? "text-rose-500 bg-rose-500/10" : lcpSec > 1.2 ? "text-amber-500 bg-amber-500/10" : "text-emerald-500 bg-emerald-500/10");
    lcpBadge.textContent = lcpSec > 2.5 ? "Kritisch" : lcpSec > 1.2 ? "Träge" : "Sehr Gut";
  }

  const inpText = document.getElementById("metric-inp-val");
  const inpBadge = document.getElementById("metric-inp-badge");
  if (inpText && inpBadge) {
    inpText.textContent = `${inpMs}ms`;
    inpBadge.className = "text-[10px] px-2 py-0.5 rounded font-mono " +
      (inpMs > 200 ? "text-rose-500 bg-rose-500/10" : inpMs > 100 ? "text-amber-500 bg-amber-500/10" : "text-emerald-500 bg-emerald-500/10");
    inpBadge.textContent = inpMs > 200 ? "Träge" : inpMs > 100 ? "Akzeptabel" : "Pfeilschnell";
  }

  const clsText = document.getElementById("metric-cls-val");
  const clsBadge = document.getElementById("metric-cls-badge");
  if (clsText && clsBadge) {
    clsText.textContent = clsInd.toFixed(2);
    clsBadge.className = "text-[10px] px-2 py-0.5 rounded font-mono " +
      (clsInd > 0.25 ? "text-rose-500 bg-rose-500/10" : clsInd > 0.1 ? "text-amber-500 bg-amber-500/10" : "text-emerald-500 bg-emerald-500/10");
    clsBadge.textContent = clsInd > 0.25 ? "Instabil" : clsInd > 0.1 ? "Variabel" : "Stabil (0 Shift)";
  }

  const reportLabel = document.getElementById("speed-feedback-report");
  if (reportLabel) {
    let reportText = "";
    if (baseScore < 50) {
      reportLabel.className = "text-xs text-rose-400 font-sans mt-1 block leading-relaxed";
      reportText = "Alarmstufe Rot. Die Ladezeit von fast 9 Sekunden ist für mobile LTE-Kunden unzumutbar. 53% der Besucher springen ab, wenn das Laden länger als 3 Sekunden dauert. Aktivieren Sie die obigen Module!";
    } else if (baseScore >= 50 && baseScore < 90) {
      reportLabel.className = "text-xs text-amber-400 font-sans mt-1 block leading-relaxed";
      reportText = "Ausreichend optimiert. Sie haben bereits entscheidende Engpässe gelöst und sind damit weitaus schneller als die Konkurrenz. Bringen Sie die restlichen Module online um die magische 90er-Marke zu knacken!";
    } else {
      reportLabel.className = "text-xs text-emerald-400 font-semibold font-sans mt-1 block leading-relaxed";
      reportText = "✓ Exzellente Arbeit! 100/100 PageSpeed gelöst. Auf unbeschränkten 5G Netzen rendert die Applikation nun komplett verzögerungsfrei. Ein heroisches Conversion-Erlebnis für E-Commerce-Zahlen.";
    }
    reportLabel.innerHTML = reportText;
  }
}

// 4. CASE STUDIES SYSTEM
function initCaseStudiesFilters() {
  const filterBtns = document.querySelectorAll(".project-filter-btn");
  filterBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      filterBtns.forEach(b => {
        b.className = "project-filter-btn px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300";
      });
      btn.className = "project-filter-btn px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-xs";

      const targetCategory = btn.getAttribute("data-category");
      renderCaseStudies(targetCategory);
    });
  });
}

function renderCaseStudies(categorySelected) {
  const showroom = document.getElementById("projects-showroom");
  if (!showroom) return;

  showroom.innerHTML = "";

  const filtered = categorySelected === "All"
    ? PROJECTS
    : PROJECTS.filter(p => p.category === categorySelected || (categorySelected === "Vanilla JS / Tech Stack" && p.category === "Vanilla JS / Tech Stack"));

  if (filtered.length === 0) {
    showroom.innerHTML = `<p class="col-span-2 text-center py-10 font-mono text-neutral-500">Keine passenden Fallstudien gefunden.</p>`;
    return;
  }

  filtered.forEach(proj => {
    const card = document.createElement("div");
    card.className = "border border-neutral-200 dark:border-neutral-800 rounded-2xl flex flex-col justify-between bg-white dark:bg-[#09090b]/40 backdrop-blur-xs shadow-xs hover:border-neutral-300 dark:hover:border-neutral-700 transition-all duration-200 dynamic-card-spacing";

    let techTags = proj.tech.map(t => `<span class="px-2 py-0.5 bg-neutral-100 dark:bg-neutral-900 border border-neutral-200/50 dark:border-neutral-800 rounded text-[10px] font-mono text-neutral-500 dark:text-neutral-300">${t}</span>`).join("");

    card.innerHTML = `
      <div>
        <div class="flex items-start justify-between gap-1.5 mb-2.5">
          <span class="inline-block text-[10px] font-mono uppercase bg-neutral-100 dark:bg-neutral-900 text-neutral-400 dark:text-neutral-500 px-2 py-0.5 rounded-full tracking-widest">${proj.category}</span>
          <span class="text-[10px] font-mono text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-md leading-none max-w-[200px] truncate text-right border border-emerald-500/15" title="${proj.impact}">${proj.impact}</span>
        </div>
        <h3 class="text-lg font-sans font-bold text-neutral-800 dark:text-neutral-200 hover:text-brand-accent transition-colors">
          ${proj.title}
        </h3>
        <p class="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed font-sans mt-2.5">
          ${proj.description}
        </p>

        <div class="mt-4 border-t border-dashed border-neutral-100 dark:border-neutral-800 pt-3">
          <span class="text-[9.5px] uppercase font-mono tracking-widest text-neutral-400 block mb-1">Herausforderung:</span>
          <ul class="list-disc pl-4 space-y-1">
            ${proj.challenges.map(c => `<li class="text-[11px] font-sans text-neutral-500 dark:text-neutral-400">${c}</li>`).join("")}
          </ul>
        </div>
      </div>

      <div class="mt-4 pt-4 border-t border-neutral-100 dark:border-neutral-850">
        <div class="flex flex-wrap gap-1.5 mb-3.5">
          ${techTags}
        </div>
        
        <button class="view-snippet-btn w-full mt-2 border border-neutral-300 dark:border-neutral-750 bg-neutral-100 dark:bg-neutral-900 hover:bg-neutral-200 dark:hover:bg-neutral-800 rounded-lg py-2 text-xs font-mono font-bold text-neutral-700 dark:text-neutral-200 transition-colors cursor-pointer" data-id="${proj.id}">
          Code vergleichen &amp; analysieren </button>
      </div>
    `;

    const actionBtn = card.querySelector(".view-snippet-btn");
    if (actionBtn) {
      actionBtn.addEventListener("click", () => {
        const id = actionBtn.getAttribute("data-id");
        const match = PROJECTS.find(p => p.id === id);
        if (match) {
          selectedInspectorProject = match;
          showLazyAlternativeCode = false;

          renderCodeInspectorSidebar();
          renderCodeInspectorWorkspace();

          const trg = document.getElementById("code-repo-viewer");
          if (trg) {
            trg.scrollIntoView({ behavior: "smooth" });
          }
        }
      });
    }

    showroom.appendChild(card);
  });
}

// 5. COMPARATIVE CODE INSPECTOR SIDEBAR & WORKSPACE
function renderCodeInspectorSidebar() {
  const sidebarContainer = document.getElementById("inspector-file-sidebar");
  if (!sidebarContainer) return;

  sidebarContainer.innerHTML = "";

  PROJECTS.forEach(proj => {
    const btn = document.createElement("button");
    btn.setAttribute("data-id", proj.id);

    const isSelected = selectedInspectorProject.id === proj.id;
    const activeClass = isSelected
      ? "bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-neutral-900 dark:text-white font-bold"
      : "text-neutral-600 dark:text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-250";

    btn.className = `w-full text-left px-3 py-2.5 rounded-lg text-xs font-mono cursor-pointer transition-all block truncate ${activeClass}`;

    const iconName = proj.codeLanguage === "php" ? "🐘 wp-core-hook.php" : "🟨 custom-element.js";
    btn.innerHTML = `
      <div class="font-semibold text-sans text-xs mb-0.5 max-w-full truncate">${proj.title}</div>
      <div class="text-[10px] opacity-75 max-w-full truncate">${iconName}</div>
    `;

    btn.addEventListener("click", () => {
      selectedInspectorProject = proj;
      showLazyAlternativeCode = false;
      renderCodeInspectorSidebar();
      renderCodeInspectorWorkspace();
    });

    sidebarContainer.appendChild(btn);
  });
}

function renderCodeInspectorWorkspace() {
  const customSauberTab = document.getElementById("tab-sauber");
  const customSlopTab = document.getElementById("tab-slop");
  const codeBlock = document.getElementById("inspector-code-block");
  const explanationLabel = document.getElementById("inspector-explanation-label");
  const feedbackItalic = document.getElementById("tab-feedback-italic");

  const activeTitle = document.getElementById("inspector-project-title");
  const activeCategory = document.getElementById("inspector-project-category");
  const activeImpact = document.getElementById("inspector-project-impact");

  if (activeTitle) {
    activeTitle.textContent = selectedInspectorProject.title;
  }
  if (activeCategory) {
    activeCategory.textContent = selectedInspectorProject.category;
  }
  if (activeImpact) {
    activeImpact.textContent = selectedInspectorProject.impact;
  }

  if (!codeBlock) return;

  if (showLazyAlternativeCode) {
    if (customSauberTab) {
      customSauberTab.className = "px-3 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1.5 text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300";
    }
    if (customSlopTab) {
      customSlopTab.className = "px-3 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1.5 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-white font-bold shadow-xs";
    }

    if (feedbackItalic) feedbackItalic.textContent = "Nicht nachmachen!";
    codeBlock.textContent = SLOP_RECIPES[selectedInspectorProject.id] || "// No Template found";

    if (explanationLabel) {
      explanationLabel.className = "font-sans leading-relaxed text-rose-400 font-medium";
      explanationLabel.textContent = `Sogenannte "Copypaste-Scripte" sparen auf den ersten Blick 10 Minuten Arbeitszeit, scheitern aber im Live-Betrieb unter Last. Sie verstoßen gegen WordPress Codestandards, haben keine Hooks zur Extension und blockieren Suchmaschinen-Indexer per CLS.`;
    }

  } else {
    if (customSauberTab) {
      customSauberTab.className = "px-3 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1.5 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-white font-bold shadow-xs";
    }
    if (customSlopTab) {
      customSlopTab.className = "px-3 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1.5 text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300";
    }

    if (feedbackItalic) feedbackItalic.textContent = "Wartungsfrei & performant";
    codeBlock.textContent = selectedInspectorProject.codeSnippet;

    if (explanationLabel) {
      explanationLabel.className = "font-sans leading-relaxed text-emerald-500 font-medium";
      explanationLabel.textContent = `Dieser Code setzt direkt auf dem nativen API-Skelett auf. Er spart hunderte KB unnötigen Framework-Bloats, ist gegen SQL-Injections gesichert und dank expliziter Assetdimensionierung absolut Layout Shift (CLS) frei.`;
    }
  }

  if (customSauberTab && !customSauberTab.dataset.listener) {
    customSauberTab.dataset.listener = "true";
    customSauberTab.addEventListener("click", () => {
      showLazyAlternativeCode = false;
      renderCodeInspectorWorkspace();
    });
  }

  if (customSlopTab && !customSlopTab.dataset.listener) {
    customSlopTab.dataset.listener = "true";
    customSlopTab.addEventListener("click", () => {
      showLazyAlternativeCode = true;
      renderCodeInspectorWorkspace();
    });
  }

  const copyBtn = document.getElementById("btn-copy-snippet");
  if (copyBtn && !copyBtn.dataset.listener) {
    copyBtn.dataset.listener = "true";
    copyBtn.addEventListener("click", () => {
      const codeToCopy = showLazyAlternativeCode
        ? (SLOP_RECIPES[selectedInspectorProject.id] || "")
        : selectedInspectorProject.codeSnippet;

      navigator.clipboard.writeText(codeToCopy).then(() => {
        const copyIcon = document.getElementById("copy-icon-svg");
        const successIcon = document.getElementById("copy-success-svg");
        const btnText = document.getElementById("copy-btn-text");

        if (copyIcon) copyIcon.classList.add("hidden");
        if (successIcon) successIcon.classList.remove("hidden");
        if (btnText) {
          btnText.textContent = "Kopiert!";
          btnText.classList.add("text-emerald-500");
        }

        setTimeout(() => {
          if (copyIcon) copyIcon.classList.remove("hidden");
          if (successIcon) successIcon.classList.add("hidden");
          if (btnText) {
            btnText.textContent = "Kopieren";
            btnText.classList.remove("text-emerald-500");
          }
        }, 2000);
      });
    });
  }
}

// 6. EXPERIENCES TIMELINE CHRONOLOGY ACCORDIONS
function renderTimelineChronology() {
  const container = document.getElementById("experience-timeline-container");
  if (!container) return;

  container.innerHTML = "";

  TIMELINE.forEach((event, idx) => {
    const node = document.createElement("div");
    node.className = "relative group";

    let techTags = event.techUsed.map(t => {
      return `<span class="px-2 py-0.5 bg-neutral-100 dark:bg-neutral-900 border border-neutral-200/50 dark:border-neutral-800 rounded text-[10px] font-mono text-neutral-600 dark:text-neutral-300 shrink-0">${t}</span>`;
    }).join("");

    const isExpanded = activeStoryIdx === idx;
    const accordionText = isExpanded ? "Factual context ausblenden ▲" : "Factual context einblenden ▼";
    const accordionClass = isExpanded ? "" : "hidden";

    node.innerHTML = `
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-2.5 mb-2.5">
        <div>
          <span class="inline-flex items-center gap-1 text-[11px] font-mono text-neutral-400 uppercase tracking-widest bg-neutral-100 dark:bg-neutral-900 px-2.5 py-0.5 rounded-full mb-1">
            <svg class="w-3 h-3 text-brand-purple" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="16" y1="2" x2="16" y2="6"></line>
              <line x1="8" y1="2" x2="8" y2="6"></line>
              <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
            <span>${event.date}</span>
          </span>
          <h4 class="text-lg font-sans font-bold text-neutral-900 dark:text-neutral-100 group-hover:text-brand-accent transition-all">
            ${event.role}
          </h4>
          <div class="text-sm font-sans font-medium text-neutral-600 dark:text-neutral-400">
            ${event.company}
          </div>
        </div>
      </div>

      <p class="text-sm text-neutral-500 dark:text-neutral-400 font-sans leading-relaxed max-w-3xl mb-4">
        ${event.description}
      </p>

      <div class="flex flex-wrap gap-1.5 mb-4">
        ${techTags}
      </div>

      <div class="bg-neutral-50 dark:bg-neutral-900/40 rounded-xl p-4 border border-neutral-100 dark:border-neutral-800 hover:border-neutral-200 dark:hover:border-neutral-700 transition-colors">
        <button class="toggle-story-btn w-full flex items-center justify-between text-left font-mono text-xs text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white transition-colors cursor-pointer focus:outline-none" data-idx="${idx}">
          <div class="flex items-center gap-2">
            <svg class="w-4 h-4 text-brand-accent shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
            </svg>
            <span class="story-btn-text text-brand-accent font-bold">${accordionText}</span>
          </div>
          <span class="text-[10px] font-bold font-mono tracking-wider uppercase px-2 py-0.5 rounded bg-neutral-200 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 leading-none">Insight</span>
        </button>

        <div class="story-body-block mt-3 text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed font-sans border-t border-neutral-200/40 dark:border-neutral-800/40 pt-2.5 ${accordionClass}">
          ${event.realStory}
        </div>
      </div>
    `;

    const tglBtn = node.querySelector(".toggle-story-btn");
    if (tglBtn) {
      tglBtn.addEventListener("click", () => {
        const clickedIdx = parseInt(tglBtn.getAttribute("data-idx"));
        activeStoryIdx = activeStoryIdx === clickedIdx ? null : clickedIdx;
        renderTimelineChronology();
      });
    }

    container.appendChild(node);
  });
}

// 7. SECURE WORDPRESS CONTACT FORM WITH DYNAMIC FALLBACK
function initRecruitingContactForm() {
  const form = document.getElementById("contact-team-form");
  const successToast = document.getElementById("form-success-toast");
  const errorToast = document.getElementById("form-error-toast");
  const submitBtn = document.getElementById("btn-submit-contact");

  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    if (successToast) successToast.classList.add("hidden");
    if (errorToast) errorToast.classList.add("hidden");

    const nameVal = document.getElementById("form-name").value.trim();
    const emailVal = document.getElementById("form-email").value.trim();
    const messageVal = document.getElementById("form-message").value.trim();

    if (!nameVal || !emailVal || !messageVal) {
      if (errorToast) {
        errorToast.classList.remove("hidden");
        errorToast.querySelector("span").textContent = "Bitte füllen Sie alle Pflichtfelder aus.";
      }
      return;
    }

    if (submitBtn) {
      submitBtn.setAttribute("disabled", "true");
      submitBtn.innerHTML = `
        <svg class="animate-spin h-3.5 w-3.5 text-white" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <span>Wird gesendet...</span>
      `;
    }

    // ← WP-MIGRATION Check if WordPress AJAX localized variables exist
    if (typeof hb_portfolio_vars !== "undefined" && hb_portfolio_vars.ajax_url) {
      const payload = new URLSearchParams();
      payload.append("action", "submit_hb_contact_form");
      payload.append("nonce", hb_portfolio_vars.nonce);
      payload.append("name", nameVal);
      payload.append("email", emailVal);
      payload.append("message", messageVal);

      fetch(hb_portfolio_vars.ajax_url, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: payload
      })
      .then(resp => resp.json())
      .then(res => {
        restoreSubmitButton();
        if (res.success) {
          if (successToast) successToast.classList.remove("hidden");
          form.reset();
        } else {
          if (errorToast) {
            errorToast.classList.remove("hidden");
            errorToast.querySelector("span").textContent = res.data || "Fehler beim Absenden.";
          }
        }
      })
      .catch(err => {
        restoreSubmitButton();
        if (errorToast) {
          errorToast.classList.remove("hidden");
          errorToast.querySelector("span").textContent = "Verbindungsfehler. Bitte versuchen Sie es erneut.";
        }
      });
    } else {
      // Offline fallback simulator
      setTimeout(() => {
        restoreSubmitButton();
        if (successToast) successToast.classList.remove("hidden");
        form.reset();
      }, 1250);
    }
  });

  function restoreSubmitButton() {
    if (submitBtn) {
      submitBtn.removeAttribute("disabled");
      submitBtn.innerHTML = `
        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <line x1="22" y1="2" x2="11" y2="13"></line>
          <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
        </svg>
        <span>Nachricht absenden</span>
      `;
    }
  }
}

// 8. KEYBOARD OVERLAY COMMAND CENTER MENU (CTRL+K)
function initCommandMenu() {
  const menuModal = document.getElementById("command-menu-modal");
  const searchInput = document.getElementById("command-search-input");
  const optionsList = document.getElementById("command-options-list");

  if (!menuModal || !searchInput || !optionsList) return;

  const toggleModal = (show) => {
    if (show) {
      menuModal.classList.remove("hidden");
      setTimeout(() => {
        menuModal.classList.remove("opacity-0", "pointer-events-none");
        searchInput.focus();
      }, 10);
    } else {
      menuModal.classList.add("opacity-0", "pointer-events-none");
      setTimeout(() => menuModal.classList.add("hidden"), 200);
      searchInput.value = "";
    }
  };

  // Keyboard shortcut bindings (Ctrl+K or Cmd+K)
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "k") {
      e.preventDefault();
      const isHidden = menuModal.classList.contains("hidden");
      toggleModal(isHidden);
    }
    if (e.key === "Escape" && !menuModal.classList.contains("hidden")) {
      toggleModal(false);
    }
  });

  // Bind close buttons
  const bgOverlay = menuModal.querySelector(".bg-black\\/60");
  if (bgOverlay) {
    bgOverlay.addEventListener("click", () => toggleModal(false));
  }

  const closeBtn = document.getElementById("btn-close-command-menu");
  if (closeBtn) {
    closeBtn.addEventListener("click", () => toggleModal(false));
  }

  // Keyboard controls over options list
  searchInput.addEventListener("input", (e) => {
    const val = e.target.value.toLowerCase().trim();
    const rows = optionsList.querySelectorAll(".cmd-option-row");
    rows.forEach(row => {
      const matchText = row.getAttribute("data-match") || "";
      if (matchText.toLowerCase().includes(val)) {
        row.style.display = "flex";
      } else {
        row.style.display = "none";
      }
    });
  });

  // Bind key actions inside list
  const optionRows = optionsList.querySelectorAll(".cmd-option-row");
  optionRows.forEach(row => {
    row.addEventListener("click", () => {
      const targetAction = row.getAttribute("data-action");
      toggleModal(false);

      if (targetAction === "scroll-timeline") {
        document.getElementById("experience")?.scrollIntoView({ behavior: "smooth" });
      } else if (targetAction === "scroll-projects") {
        document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" });
      } else if (targetAction === "scroll-analyzer") {
        document.getElementById("vitals-analyzer")?.scrollIntoView({ behavior: "smooth" });
      } else if (targetAction === "scroll-contact") {
        document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
      } else if (targetAction === "download-cv") {
        document.getElementById("btn-download-cv")?.click();
      } else if (targetAction === "toggle-dark") {
        document.getElementById("theme-toggle-btn")?.click();
      } else if (targetAction === "open-engine") {
        document.getElementById("btn-toggle-layout-engine")?.click();
      }
    });
  });
}

// 9. career pdf downloader module using jsPDF
function initCvDownloader() {
  const downloadBtns = document.querySelectorAll(".cv-download-trigger");
  downloadBtns.forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();

      // Check if global jsPDF constructor exists
      if (typeof window.jspdf === "undefined") {
        alert("Das PDF-Modul wird noch geladen oder konnte nicht über das CDN bezogen werden. Bitte versuchen Sie es in Kürze erneut.");
        return;
      }

      try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF("p", "mm", "a4");

        const marginX = 20;
        const pageHeight = 297;
        const contentWidth = 170; // 210 - 2 * 20

        const drawPageDecoration = (pageNumber) => {
          doc.setLineWidth(0.4);
          doc.setDrawColor(6, 182, 212); // #06b6d4 Brand cyan
          doc.line(marginX, 15, 210 - marginX, 15);

          doc.setFont("helvetica", "normal");
          doc.setFontSize(8);
          doc.setTextColor(150, 150, 150);
          doc.text("Hussein Bawab — Entwickler-Lebenslauf 2026", marginX, 287);
          doc.text(`Seite ${pageNumber} von 3`, 210 - marginX - 15, 287);
        };

        // ================= PAGE 1 =================
        drawPageDecoration(1);
        let y = 30;

        // Header Title
        doc.setFont("helvetica", "bold");
        doc.setFontSize(24);
        doc.setTextColor(17, 17, 17);
        doc.text("Hussein Bawab", marginX, y);
        y += 7.5;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(11);
        doc.setTextColor(100, 100, 100);
        doc.text("Senior Full-Stack Webentwickler & Software-Architekt", marginX, y);
        y += 14;

        // Contact particulars block
        doc.setLineWidth(0.2);
        doc.setDrawColor(220, 220, 220);
        doc.line(marginX, y, 210 - marginX, y);
        y += 7;

        doc.setFontSize(9);
        doc.setTextColor(60, 60, 60);
        doc.text("Email: info@husseinbawab.de", marginX, y);
        doc.text("Wohnort: Hamburg, Deutschland", marginX + 80, y);
        y += 5.5;
        doc.text("Mobil: +49 (0) 152 169 229 55", marginX, y);
        doc.text("Web: www.husseinbawab.de", marginX + 80, y);
        y += 10;

        doc.setLineWidth(0.25);
        doc.line(marginX, y, 210 - marginX, y);
        y += 12;

        // BERUFLICHER WERDEGANG
        doc.setFont("helvetica", "bold");
        doc.setFontSize(14);
        doc.setTextColor(17, 17, 17);
        doc.text("BERUFLICHER WERDEGANG", marginX, y);
        y += 10;

        // Job 1
        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.setTextColor(30, 30, 30);
        doc.text("10/2021 – Aktuell: Senior Full-Stack Webentwickler", marginX, y);
        y += 5;
        doc.setFont("helvetica", "italic");
        doc.setFontSize(9.5);
        doc.setTextColor(90, 90, 90);
        doc.text("Hussein Bawab – IT & Web-Engineering, Berlin / Hamburg (Selbstständig/Freelance)", marginX, y);
        y += 6.5;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(60, 60, 60);
        const j1Desc = "Umsetzung hochperformanter Webplattformen und Custom Themes für namhafte DACH-Kunden. Härtung von WordPress-Sicherheitsstrukturen, Integration komplexer Cloud-Dienste und Optimierung von Lieferschnittstellen.";
        const splitJ1 = doc.splitTextToSize(j1Desc, contentWidth);
        doc.text(splitJ1, marginX, y);
        y += (splitJ1.length * 4.5) + 4;

        const bulletPointsJ1 = [
          "• Custom API Integrationen & WordPress Hooks",
          "• Skalierung von WooCommerce Datenbank-Indizes",
          "• LCP Performance Auditing & Edge Cache Setups"
        ];
        bulletPointsJ1.forEach(pt => {
          doc.text(pt, marginX + 4, y);
          y += 4.5;
        });

        y += 6;

        // Job 2
        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.setTextColor(30, 30, 30);
        doc.text("04/2020 – 09/2021: Full-Stack Webentwickler", marginX, y);
        y += 5;
        doc.setFont("helvetica", "italic");
        doc.setFontSize(9.5);
        doc.setTextColor(90, 90, 90);
        doc.text("Pirelli Deutschland GmbH, Berlin / Hamburg", marginX, y);
        y += 6.5;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(60, 60, 60);
        const j2Desc = "Entwicklung und Maintenance unternehmensweiter Webapplikationen im B2B-Umfeld zur Optimierung und Automatisierung interner Vertriebswege.";
        const splitJ2 = doc.splitTextToSize(j2Desc, contentWidth);
        doc.text(splitJ2, marginX, y);
        y += (splitJ2.length * 4.5) + 4;

        const bulletPointsJ2 = [
          "• Erstellung echtzeitfähiger Reifendaten-Schnittstellen",
          "• API Optimierungen zur Synchronisierung riesiger Produktkataloge",
          "• Reduzierung zeitkritischer DB Blocking IO Locks"
        ];
        bulletPointsJ2.forEach(pt => {
          doc.text(pt, marginX + 4, y);
          y += 4.5;
        });

        // ================= PAGE 2 =================
        doc.addPage();
        drawPageDecoration(2);
        y = 25;

        // Job 3
        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.setTextColor(30, 30, 30);
        doc.text("04/2018 – 03/2020: Full-Stack Webentwickler", marginX, y);
        y += 5;
        doc.setFont("helvetica", "italic");
        doc.setFontSize(9.5);
        doc.setTextColor(90, 90, 90);
        doc.text("E-Commerce-Agentur Active-Storefront, Hamburg", marginX, y);
        y += 6.5;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(60, 60, 60);
        const j3Desc = "Entwicklung nativer Plugins und Performance-Optimierungen für wachsende DACH E-Commerce Brands auf Basis agiler Agenturprozesse.";
        const splitJ3 = doc.splitTextToSize(j3Desc, contentWidth);
        doc.text(splitJ3, marginX, y);
        y += (splitJ3.length * 4.5) + 4;

        const bulletPointsJ3 = [
          "• Entwicklung individueller Theme Boilerplates",
          "• Erfolgreiche Launches von Web-Performance Systemen",
          "• Etablierung automatisierter Deployments"
        ];
        bulletPointsJ3.forEach(pt => {
          doc.text(pt, marginX + 4, y);
          y += 4.5;
        });

        y += 10;
        doc.setLineWidth(0.25);
        doc.setDrawColor(210, 210, 210);
        doc.line(marginX, y, 210 - marginX, y);
        y += 10;

        // AUSBILDUNG
        doc.setFont("helvetica", "bold");
        doc.setFontSize(14);
        doc.setTextColor(17, 17, 17);
        doc.text("AUSBILDUNG", marginX, y);
        y += 10;

        // Uni
        doc.setFont("helvetica", "bold");
        doc.setFontSize(10.5);
        doc.setTextColor(30, 30, 30);
        doc.text("02/2012 – 10/2016: Bachelor of Computer Science", marginX, y);
        y += 4.5;
        doc.setFont("helvetica", "italic");
        doc.setFontSize(9.5);
        doc.setTextColor(90, 90, 90);
        doc.text("State University of Computer Science & Applied Arts (Exzellenzgrad)", marginX, y);
        y += 10;

        // Schule
        doc.setFont("helvetica", "bold");
        doc.setFontSize(10.5);
        doc.setTextColor(30, 30, 30);
        doc.text("08/2002 – 05/2005: Zeugnis der Allgemeinen Hochschulreife", marginX, y);
        y += 4.5;
        doc.setFont("helvetica", "italic");
        doc.setFontSize(9.5);
        doc.setTextColor(90, 90, 90);
        doc.text("Behörde für Schule, Jugend und Berufsbildung, Hamburg", marginX, y);
        y += 10;

        // Deutschkurs
        doc.setFont("helvetica", "bold");
        doc.setFontSize(10.5);
        doc.setTextColor(30, 30, 30);
        doc.text("12/2001 – 07/2002: Deutschsprachkurs", marginX, y);
        y += 4.5;
        doc.setFont("helvetica", "italic");
        doc.setFontSize(9.5);
        doc.setTextColor(90, 90, 90);
        doc.text("D.A.B St. Pauli, Hamburg", marginX, y);
        y += 12;

        // WEITERBILDUNG
        doc.setFont("helvetica", "bold");
        doc.setFontSize(14);
        doc.setTextColor(17, 17, 17);
        doc.text("WEITERBILDUNG", marginX, y);
        y += 10;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(10);
        doc.setTextColor(35, 35, 35);
        doc.text("02/2017 – 10/2017: Zertifizierungen — GFN AG, Hamburg", marginX, y);
        y += 5.5;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(60, 60, 60);
        const trainingBullets = [
          "• Certified Developer (JavaScript)",
          "• Certified Developer (PHP & MySQL)",
          "• Certified Web Architecture",
          "• Certified Online Marketing Management",
          "• Certified Web Interface Designer"
        ];
        trainingBullets.forEach(bullet => {
          const splitB = doc.splitTextToSize(bullet, contentWidth);
          doc.text(splitB, marginX, y);
          y += (splitB.length * 4.5) + 1.2;
        });

        // ================= PAGE 3 =================
        doc.addPage();
        drawPageDecoration(3);
        y = 25;

        // IT-KENNTNISSE & FÄHIGKEITEN
        doc.setFont("helvetica", "bold");
        doc.setFontSize(14);
        doc.setTextColor(17, 17, 17);
        doc.text("IT-KENNTNISSE & FÄHIGKEITEN", marginX, y);
        y += 10;

        const drawSkillsRow = (label, details) => {
          doc.setFont("helvetica", "bold");
          doc.setFontSize(10);
          doc.setTextColor(40, 40, 40);
          doc.text(label, marginX, y);

          doc.setFont("helvetica", "normal");
          doc.setFontSize(9);
          doc.setTextColor(65, 65, 65);

          const textX = marginX + 38;
          const textW = contentWidth - 38;
          const splitD = doc.splitTextToSize(details, textW);
          doc.text(splitD, textX, y);

          y += (splitD.length * 4.5) + 6;
        };

        drawSkillsRow("Core Skills", "Frontend Entwicklung, Backend Entwicklung, Responsive Webdesign, Barrierefreiheit (Accessibility), Web-Performance Optimierung, SEO");
        drawSkillsRow("Technologien", "JavaScript (fortgeschritten), PHP & MySQL (fortgeschritten), HTML5 / CSS3 (Expertenniveau), React (Grundkenntnisse), Vue.js (Grundkenntnisse)");
        drawSkillsRow("CMS & E-Commerce", "WordPress (umfangreiche Erfahrung), Shopware 5 & 6 (Konfiguration & Customization), Shopify (Implementierung)");
        drawSkillsRow("Tools & Workflows", "Git, VS Code, Browser DevTools, Hosting & Deployment, Agentur-Workflows, Technisches Schreiben (Dokumentation)");

        y += 6;
        doc.setDrawColor(210, 210, 210);
        doc.setLineWidth(0.25);
        doc.line(marginX, y, 210 - marginX, y);
        y += 10;

        // SPRACHKENNTNISSE
        doc.setFont("helvetica", "bold");
        doc.setFontSize(14);
        doc.setTextColor(17, 17, 17);
        doc.text("SPRACHKENNTNISSE", marginX, y);
        y += 8;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(9.5);
        doc.setTextColor(60, 60, 60);
        doc.text("• Arabisch: Muttersprache", marginX, y);
        y += 5.5;
        doc.text("• Englisch: Zweite Muttersprache / Fließend", marginX, y);
        y += 5.5;
        doc.text("• Deutsch: Fließend (Niveau C1)", marginX, y);

        doc.save("Hussein_Bawab_CV_2026.pdf");
      } catch (err) {
        console.error("PDF generation failed:", err);
        alert("Der PDF-Download ist fehlgeschlagen. Der Lebenslauf wird als Text in der Konsole ausgegeben.");
      }
    });
  });
}

// 10. SETUP HAMBURGER DROP DOWN NAV
function initMobileHamburgerDropdown() {
  const burgerBtn = document.getElementById("mobile-hamburger-btn");
  const mobileMenu = document.getElementById("mobile-menu");

  if (!burgerBtn || !mobileMenu) return;

  burgerBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    mobileMenu.classList.toggle("hidden");
  });

  document.addEventListener("click", (e) => {
    if (!mobileMenu.classList.contains("hidden")) {
      if (!mobileMenu.contains(e.target) && !burgerBtn.contains(e.target)) {
        mobileMenu.classList.add("hidden");
      }
    }
  });
}

// 11. SMOOTH SCROLLS ANCHORS
function setupAnchorLinksSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault();
      const targetHash = this.getAttribute("href");
      if (targetHash === "#") return;

      const targetEl = document.getElementById(targetHash.substring(1));
      if (targetEl) {
        targetEl.scrollIntoView({
          behavior: "smooth"
        });

        const mobMenu = document.getElementById("mobile-menu");
        if (mobMenu) mobMenu.classList.add("hidden");
      }
    });
  });
}
