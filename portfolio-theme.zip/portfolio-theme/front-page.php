<?php
/**
 * Hussein Bawab Portfolio — Front Page template (front-page.php)
 * All WordPress migrations are marked clearly.
 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct file execution
}

get_header(); // ← WP-MIGRATION: Header load
?>

<!-- HERO / INTRODUCTORY GREETINGS VIEW -->
<section class="relative overflow-hidden border-b border-neutral-300 dark:border-neutral-700">
  <!-- Editorial Dot grid background pattern -->
  <div id="hero-grid-bg" class="absolute inset-0 opacity-40 select-none pointer-events-none editorial-grid"></div>

  <div class="max-w-6xl mx-auto px-3 sm:px-6 md:px-12 lg:px-20 xl:px-32 flex flex-col dynamic-section-spacing">
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center relative z-10">
      
      <!-- Hero Left Side: Description Details -->
      <div class="lg:col-span-7 flex flex-col justify-center">
        
        <!-- Tagline Label -->
        <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold text-brand-accent uppercase bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 tracking-widest mb-4 w-max">
          <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
          <span>ROOT // DEVELOPER_INFO</span>
        </div>

        <!-- Main Heading H1 Title -->
        <h1 class="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-sans font-black leading-[1.05] tracking-tight mb-2 text-neutral-900 dark:text-neutral-50 dynamic-header-font">
          Hussein <span class="text-brand-accent">Bawab</span>
        </h1>
        
        <h2 class="text-xl sm:text-2xl md:text-3xl font-extrabold text-neutral-800 dark:text-neutral-300 tracking-tight mb-4 leading-tight">
          High-End Webentwicklung & Software-Architektur.
        </h2>

        <!-- Secondary description narrative text -->
        <p class="text-sm sm:text-base text-neutral-500 dark:text-neutral-400 leading-relaxed mb-6 max-w-2xl dynamic-body-font">
          Ich befreie anspruchsvolle Marken von schwerfälligen Baukastensystemen. Jedes Projekt wird von Grund auf mit performantem, semantischem Code entwickelt — für bahnbrechende Ladezeiten, makellose SEO und messbar mehr Conversions.
        </p>

        <!-- Metriken Trust Bar -->
        <div class="grid grid-cols-3 gap-4 border-t border-neutral-200 dark:border-neutral-800 pt-5 mb-6 max-w-md">
          <div>
            <div class="text-xl sm:text-2xl font-black font-mono text-neutral-900 dark:text-neutral-50 tracking-tight">&lt;0.4s</div>
            <span class="text-[9px] font-mono uppercase tracking-wider text-neutral-400 dark:text-neutral-500">Ø Ladezeit</span>
          </div>
          <div>
            <div class="text-xl sm:text-2xl font-black font-mono text-neutral-900 dark:text-neutral-50 tracking-tight">100/100</div>
            <span class="text-[9px] font-mono uppercase tracking-wider text-neutral-400 dark:text-neutral-500">PageSpeed</span>
          </div>
          <div>
            <div class="text-xl sm:text-2xl font-black font-mono text-neutral-900 dark:text-neutral-50 tracking-tight">0% Bloat</div>
            <span class="text-[9px] font-mono uppercase tracking-wider text-neutral-400 dark:text-neutral-500">Clean Code</span>
          </div>
        </div>

        <!-- CTA Navigation button triggers -->
        <div class="flex flex-wrap items-center gap-4">
          <a href="#projects" class="rounded-lg bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black py-3 px-5 text-xs font-semibold hover:scale-[1.01] active:scale-[0.99] transition-all shadow-md flex items-center gap-1.5 cursor-pointer">
            <!-- Coding icon -->
            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
              <polyline points="16 18 22 12 16 6"></polyline>
              <polyline points="8 6 2 12 8 18"></polyline>
            </svg>
            <span>Projekte ansehen</span>
          </a>

          <a href="#vitals-analyzer" class="rounded-lg border border-neutral-300 dark:border-neutral-800 bg-white/65 dark:bg-neutral-900/65 hover:bg-neutral-100/80 dark:hover:bg-neutral-800/80 py-3 px-5 text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer">
            <!-- Cpu icon -->
            <svg class="w-4 h-4 text-brand-purple" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect>
              <rect x="9" y="9" width="6" height="6"></rect>
              <line x1="9" y1="1" x2="9" y2="4"></line>
              <line x1="15" y1="1" x2="15" y2="4"></line>
              <line x1="9" y1="20" x2="9" y2="23"></line>
              <line x1="15" y1="20" x2="15" y2="23"></line>
              <line x1="20" y1="9" x2="23" y2="9"></line>
              <line x1="20" y1="15" x2="23" y2="15"></line>
              <line x1="1" y1="9" x2="4" y2="9"></line>
              <line x1="1" y1="15" x2="4" y2="15"></line>
            </svg>
            <span>Speed-Auditor</span>
          </a>
        </div>

      </div>

      <!-- Hero Right Side: Responsive Technical Showcase Box -->
      <div class="lg:col-span-5 flex flex-col justify-center relative w-full mt-4 lg:mt-0">
        <div class="relative rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white/80 dark:bg-neutral-950/80 p-5 md:p-6 backdrop-blur-md shadow-xl flex flex-col gap-5 overflow-hidden">
          <!-- Card header: Code Editor Mockup icon -->
          <div class="flex items-center justify-between border-b border-neutral-100 dark:border-neutral-900 pb-3">
            <div class="flex items-center gap-1.5">
              <span class="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
              <span class="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            </div>
            <div class="font-mono text-[9px] text-neutral-400 uppercase tracking-widest">
              bawab-pipeline.ts
            </div>
          </div>

          <!-- Active Code Window Display -->
          <div class="font-mono text-xs text-neutral-700 dark:text-neutral-300 leading-relaxed overflow-x-auto space-y-1 py-1">
            <div class="text-neutral-400 dark:text-neutral-500">// Das Rezept für perfekte Core Web Vitals</div>
            <div><span class="text-purple-500 dark:text-purple-400 font-bold">const</span> bawabEngine = {</div>
            <div class="pl-4">speedScore: <span class="text-emerald-500 font-bold">100</span>,</div>
            <div class="pl-4">customSsr: <span class="text-amber-500 font-bold">true</span>,</div>
            <div class="pl-4">gzipSize: <span class="text-indigo-500 font-bold">"14.2kb"</span>,</div>
            <div class="pl-4">dependencies: [<span class="text-neutral-400">"none"</span>],</div>
            <div class="pl-4">layoutShift: <span class="text-emerald-500 font-bold">0.00</span></div>
            <div>};</div>
          </div>

          <!-- Metrics Visualizer Box -->
          <div class="rounded-xl bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-200 dark:border-neutral-800/80 p-4 space-y-3.5">
            <div class="flex items-center justify-between text-[10px] border-b border-neutral-100 dark:border-neutral-900/50 pb-2">
              <span class="font-bold text-neutral-800 dark:text-neutral-200 tracking-wider">REALTIME TELEMETRY</span>
              <span class="flex h-2 w-2 relative">
                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
            </div>
            <div class="space-y-2.5">
              <!-- Progress bar items -->
              <div>
                <div class="flex items-center justify-between text-[10px] mb-1 font-mono">
                  <span class="text-neutral-400">Lighthouse Performance</span>
                  <span class="font-bold text-emerald-500">100/100</span>
                </div>
                <div class="w-full bg-neutral-200 dark:bg-neutral-800 h-1 rounded-full overflow-hidden">
                  <div class="h-full bg-emerald-500 rounded-full transition-all duration-500 animate-pulse" style="width: 100%"></div>
                </div>
              </div>
              <div>
                <div class="flex items-center justify-between text-[10px] mb-1 font-mono">
                  <span class="text-neutral-400">Accessibility Rating</span>
                  <span class="font-bold text-brand-accent">100%</span>
                </div>
                <div class="w-full bg-neutral-200 dark:bg-neutral-800 h-1 rounded-full overflow-hidden">
                  <div class="h-full bg-brand-accent rounded-full transition-all duration-500" style="width: 100%"></div>
                </div>
              </div>
              <div>
                <div class="flex items-center justify-between text-[10px] mb-1 font-mono">
                  <span class="text-neutral-400">SEO Score</span>
                  <span class="font-bold text-purple-500">100%</span>
                </div>
                <div class="w-full bg-neutral-200 dark:bg-neutral-800 h-1 rounded-full overflow-hidden">
                  <div class="h-full bg-purple-500 rounded-full transition-all duration-500" style="width: 100%"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- PERFORMANCE SIMULATOR SPEED AUDITOR MODULE -->
<section id="vitals-analyzer" class="max-w-6xl mx-auto px-3 sm:px-6 md:px-12 lg:px-20 xl:px-32 border-b border-neutral-300 dark:border-neutral-700">
  <div class="flex flex-col dynamic-section-spacing">
    
    <!-- Section title -->
    <div class="max-w-3xl">
      <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold text-brand-accent uppercase bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 tracking-widest mb-4 w-max">
        <svg class="w-3.5 h-3.5 text-brand-accent shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
        </svg>
        <span>Performance als Handwerk</span>
      </div>
      <h2 class="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight mb-4 text-neutral-900 dark:text-neutral-50 dynamic-header-font">
        Warum 100/100 PageSpeed kein Luxus ist, sondern bares Geld wert.
      </h2>
      <p class="text-neutral-500 dark:text-neutral-400 leading-relaxed dynamic-body-font">
        Wer standardmäßige Page-Builder (Elementor, Divi) überlädt oder unstrukturierte Shopify-Apps unüberlegt anhäuft, verliert bis zu 40% seiner mobilen Besucher an die Ladezeit. Experimentieren Sie mit meinem interaktiven Simulator unten und sehen Sie, was saubere Frontend-Entwicklung bewirkt:
      </p>
    </div>

    <!-- Simulator grid implementation -->
    <div class="rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950/80 p-6 md:p-8 flex flex-col md:grid md:grid-cols-12 gap-8 shadow-sm dynamic-card-spacing">
      
      <!-- Left Diagnostic score side (5 col) -->
      <div class="md:col-span-12 lg:col-span-5 flex flex-col items-center justify-between border-b lg:border-b-0 lg:border-r border-neutral-100 dark:border-neutral-800 pb-8 lg:pb-0 lg:pr-8">
        <div class="text-center w-full mb-4">
          <div class="flex items-center justify-center gap-2 text-xs font-mono text-neutral-400 uppercase tracking-widest mb-1">
            <!-- Gauge icon -->
            <svg class="w-3.5 h-3.5 text-brand-accent animate-pulse" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path d="M12 2a10 10 0 0 1 7.54 16.59l-1.41-1.41a8 8 0 1 0-12.26 0l-1.41 1.41A10 10 0 0 1 12 2z"></path>
              <polyline points="12 12 16 8"></polyline>
            </svg>
            <span>Lighthouse Analyzer</span>
          </div>
          <h3 class="text-sm font-sans font-medium text-neutral-700 dark:text-neutral-300">Live Speed-Simulation</h3>
        </div>

        <!-- Central LightHouse Gauge wheel -->
        <div class="relative w-40 h-40 flex items-center justify-center my-6">
          <!-- Gauge Circle SVG -->
          <svg class="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="40" class="stroke-neutral-200 dark:stroke-neutral-800 fill-none" stroke-width="8" />
            <circle id="gauge-fill-circle" cx="50" cy="50" r="40" class="fill-none stroke-rose-500 transition-all duration-350" stroke-width="8" stroke-dasharray="251.2" stroke-dashoffset="155.7" stroke-linecap="round" />
          </svg>
          <div class="absolute inset-0 flex flex-col items-center justify-center">
            <span id="score-text-val" class="text-4xl font-extrabold font-mono leading-none tracking-tight text-rose-500">38</span>
            <span class="text-[10px] uppercase font-bold tracking-widest text-neutral-400 mt-1">Score</span>
          </div>
        </div>

        <!-- Critical Vitals metrics checklist detailed metrics parameters -->
        <div class="w-full space-y-3.5">
          
          <!-- LCP vitals row -->
          <div class="flex items-center justify-between">
            <div class="flex flex-col">
              <span class="text-xs font-mono font-medium text-neutral-500 dark:text-neutral-400">LCP (Largest Contentful Paint)</span>
              <span class="text-[10px] text-neutral-400 font-sans mt-0.5">Wann Hauptinhalt geladen ist</span>
            </div>
            <div class="flex items-center gap-2">
              <span id="metric-lcp-val" class="text-sm font-mono font-bold text-neutral-800 dark:text-neutral-200">8.80s</span>
              <span id="metric-lcp-badge" class="text-[10px] px-2 py-0.5 rounded font-mono text-rose-500 bg-rose-500/10">Kritisch</span>
            </div>
          </div>

          <!-- INP vitals row -->
          <div class="flex items-center justify-between">
            <div class="flex flex-col">
              <span class="text-xs font-mono font-medium text-neutral-500 dark:text-neutral-400">INP (Interaction to Next Paint)</span>
              <span class="text-[10px] text-neutral-400 font-sans mt-0.5">Reaktionszeit bei Mausklicks</span>
            </div>
            <div class="flex items-center gap-2">
              <span id="metric-inp-val" class="text-sm font-mono font-bold text-neutral-800 dark:text-neutral-200">210ms</span>
              <span id="metric-inp-badge" class="text-[10px] px-2 py-0.5 rounded font-mono text-rose-500 bg-rose-500/10">Träge</span>
            </div>
          </div>

          <!-- CLS vitals row -->
          <div class="flex items-center justify-between">
            <div class="flex flex-col">
              <span class="text-xs font-mono font-medium text-neutral-500 dark:text-neutral-400">CLS (Cumulative Layout Shift)</span>
              <span class="text-[10px] text-neutral-400 font-sans mt-0.5">Stabilität des visuellen Contents</span>
            </div>
            <div class="flex items-center gap-2">
              <span id="metric-cls-val" class="text-sm font-mono font-bold text-neutral-800 dark:text-neutral-200">0.42</span>
              <span id="metric-cls-badge" class="text-[10px] px-2 py-0.5 rounded font-mono text-rose-500 bg-rose-500/10">Instabil</span>
            </div>
          </div>

        </div>

        <!-- Benchmarks explanation footnotes -->
        <div class="hidden lg:block text-[10px] font-mono text-neutral-400 dark:text-neutral-500 text-center w-full mt-6 leading-relaxed">
          *Die Skala basiert auf echten Google Labs Benchmarks. Die Einsparungen sind mathematisch hergeleitet aus echten Hosting-Analysen.
        </div>

      </div>

      <!-- Right Sliders bottleneck checkpoints (7 col) -->
      <div class="md:col-span-12 lg:col-span-7 flex flex-col justify-between">
        
        <!-- Check-list Title block -->
        <div class="mb-4">
          <h3 class="text-base font-sans font-bold text-neutral-800 dark:text-neutral-100 flex items-center gap-2">
            <!-- Zap icon -->
            <svg class="w-4 h-4 text-brand-accent" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
              <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
            </svg>
            <span>Flaschenhälse beheben</span>
          </h3>
          <p class="text-xs text-neutral-600 dark:text-neutral-300 font-sans mt-1">
            Klicken Sie auf die Optimierungsschritte unten, um sie im Code zu aktivieren und zu sehen, wie die Ladelatenzen (Lighthouse Score) fallen.
          </p>
        </div>

        <!-- Checkbox selection blocks slider cards -->
        <div class="space-y-4">
          
          <!-- Option images -->
          <div id="card-opt-images" class="opt-card-btn border rounded-xl p-4 transition-all hover:bg-neutral-50 dark:hover:bg-neutral-900/40 cursor-pointer flex flex-col gap-3 items-start justify-between border-neutral-200 dark:border-neutral-800" data-optid="images-opt">
            <div class="flex-1 w-full">
              <div class="flex items-center gap-2">
                <span class="status-dot w-2 h-2 rounded-full bg-neutral-300 dark:bg-neutral-600"></span>
                <h5 class="text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300">Bildformate &amp; Lazy Loading</h5>
                <span class="badge-status text-[9px] font-mono text-rose-500 bg-rose-500/10 px-1.5 py-0.2 rounded font-semibold uppercase">Inaktiv</span>
              </div>
              <p class="text-xs text-neutral-400 dark:text-neutral-500 mt-1 leading-normal font-sans">
                Bilder ohne Dimensionen verursachen Layout-Verschiebungen (CLS). Fehlendes Lazy Loading verlangsamt das Render-Fenster dramatisch.
              </p>
              <div class="text-[11px] font-mono mt-2 text-neutral-600 dark:text-neutral-400 feedback-label">
                <span>✗ Schwere PNGs (4MB) ohne 'width/height' &amp; LazyLoad</span>
              </div>
            </div>
            <div class="flex flex-row items-center justify-between w-full mt-2 pt-2 border-t border-neutral-100 dark:border-neutral-800 shrink-0">
              <span class="text-[10px] font-mono text-neutral-400">Effekt:</span>
              <span class="effect-detail text-xs font-mono text-neutral-400">-3.4s LCP, -0.28 CLS</span>
            </div>
          </div>

          <!-- Option scripts -->
          <div id="card-opt-scripts" class="opt-card-btn border rounded-xl p-4 transition-all hover:bg-neutral-50 dark:hover:bg-neutral-900/40 cursor-pointer flex flex-col gap-3 items-start justify-between border-neutral-200 dark:border-neutral-800" data-optid="scripts-opt">
            <div class="flex-1 w-full">
              <div class="flex items-center gap-2">
                <span class="status-dot w-2 h-2 rounded-full bg-neutral-300 dark:bg-neutral-600"></span>
                <h5 class="text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300">Drittanbieter-Skripte (GTM / GA / FB)</h5>
                <span class="badge-status text-[9px] font-mono text-rose-500 bg-rose-500/10 px-1.5 py-0.2 rounded font-semibold uppercase">Inaktiv</span>
              </div>
              <p class="text-xs text-neutral-400 dark:text-neutral-500 mt-1 leading-normal font-sans">
                Marketing-Pixel rufen hunderte KB an JavaScript auf, blockieren die CPU und verzögern somit LCP sowie die Reaktion auf Klicks (INP).
              </p>
              <div class="text-[11px] font-mono mt-2 text-neutral-600 dark:text-neutral-400 feedback-label">
                <span>✗ Synchrone Einbindung im &lt;head&gt; (blockiert Parser)</span>
              </div>
            </div>
            <div class="flex flex-row items-center justify-between w-full mt-2 pt-2 border-t border-neutral-100 dark:border-neutral-800 shrink-0">
              <span class="text-[10px] font-mono text-neutral-400">Effekt:</span>
              <span class="effect-detail text-xs font-mono text-neutral-400">-2.5s LCP, -180ms INP</span>
            </div>
          </div>

          <!-- Option fonts -->
          <div id="card-opt-fonts" class="opt-card-btn border rounded-xl p-4 transition-all hover:bg-neutral-50 dark:hover:bg-neutral-900/40 cursor-pointer flex flex-col gap-3 items-start justify-between border-neutral-200 dark:border-neutral-800" data-optid="fonts-opt">
            <div class="flex-1 w-full">
              <div class="flex items-center gap-2">
                <span class="status-dot w-2 h-2 rounded-full bg-neutral-300 dark:bg-neutral-600"></span>
                <h5 class="text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300">Web-Font Einbindung</h5>
                <span class="badge-status text-[9px] font-mono text-rose-500 bg-rose-500/10 px-1.5 py-0.2 rounded font-semibold uppercase">Inaktiv</span>
              </div>
              <p class="text-xs text-neutral-400 dark:text-neutral-500 mt-1 leading-normal font-sans">
                Der Font-Download blockiert das Schriftrendereingaben. swap sorgt dafür, dass sofort eine Systemschrift greift.
              </p>
              <div class="text-[11px] font-mono mt-2 text-neutral-600 dark:text-neutral-400 feedback-label">
                <span>✗ Standard TTF ohne swap (verursacht unsichtbaren Text)</span>
              </div>
            </div>
            <div class="flex flex-row items-center justify-between w-full mt-2 pt-2 border-t border-neutral-100 dark:border-neutral-800 shrink-0">
              <span class="text-[10px] font-mono text-neutral-400">Effekt:</span>
              <span class="effect-detail text-xs font-mono text-neutral-400">-1.1s LCP, -110ms CLS</span>
            </div>
          </div>

          <!-- Option css -->
          <div id="card-opt-css" class="opt-card-btn border rounded-xl p-4 transition-all hover:bg-neutral-50 dark:hover:bg-neutral-900/40 cursor-pointer flex flex-col gap-3 items-start justify-between border-neutral-200 dark:border-neutral-800" data-optid="css-opt">
            <div class="flex-1 w-full">
              <div class="flex items-center gap-2">
                <span class="status-dot w-2 h-2 rounded-full bg-neutral-300 dark:bg-neutral-600"></span>
                <h5 class="text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300">CSS-Delivery</h5>
                <span class="badge-status text-[9px] font-mono text-rose-500 bg-rose-500/10 px-1.5 py-0.2 rounded font-semibold uppercase">Inaktiv</span>
              </div>
              <p class="text-xs text-neutral-400 dark:text-neutral-500 mt-1 leading-normal font-sans">
                Sämtliches CSS eines Monolithen blockiert standardmäßig das initiale Rendering. Nur kritisches inline zu laden spart Latenz.
              </p>
              <div class="text-[11px] font-mono mt-2 text-neutral-600 dark:text-neutral-400 feedback-label">
                <span>✗ Megabyte-großes Framework-CSS (All-in-one)</span>
              </div>
            </div>
            <div class="flex flex-row items-center justify-between w-full mt-2 pt-2 border-t border-neutral-100 dark:border-neutral-800 shrink-0">
              <span class="text-[10px] font-mono text-neutral-400">Effekt:</span>
              <span class="effect-detail text-xs font-mono text-neutral-400">-1.8s LCP</span>
            </div>
          </div>

        </div>

        <!-- Diagnostic feedback report card box -->
        <div class="mt-6 bg-neutral-50 dark:bg-neutral-900/60 rounded-xl p-4 border border-neutral-100 dark:border-neutral-800 flex items-start gap-3">
          <!-- Eye view icon -->
          <svg class="w-5 h-5 text-brand-purple shrink-0 mt-0.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
            <circle cx="12" cy="12" r="3"></circle>
          </svg>
          <div>
            <span class="text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300 block">Optimierungsempfehlung:</span>
            <span id="speed-feedback-report" class="text-xs text-rose-400 font-sans mt-1 block leading-relaxed">
              Alarmstufe Rot. Die Ladezeit von fast 9 Sekunden ist für mobile LTE-Kunden unzumutbar. 53% der Besucher springen ab, wenn das Laden länger als 3 Sekunden dauert. Aktivieren Sie die obigen Module!
            </span>
          </div>
        </div>

      </div>

    </div>

  </div>
</section>

<!-- PORTFOLIO CASE STUDIES PROJECT VIEW -->
<section id="projects" class="max-w-6xl mx-auto px-3 sm:px-6 md:px-12 lg:px-20 xl:px-32 border-b border-neutral-300 dark:border-neutral-700">
  <div class="flex flex-col dynamic-section-spacing">
    
    <!-- Header and categories tabs -->
    <div class="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
      <div class="max-w-xl">
        <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold text-brand-accent uppercase bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 tracking-widest mb-4 w-max">
          <svg class="w-3.5 h-3.5 text-brand-accent shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
          </svg>
          <span>FALLSTUDIEN</span>
        </div>
        <h2 class="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight mb-3 text-neutral-900 dark:text-neutral-50 dynamic-header-font">
          Echte Projekte. Echte Codezeilen.
        </h2>
        <p class="text-neutral-500 dark:text-neutral-400 leading-relaxed dynamic-body-font">
          Keine reinen Template-Projekte aus der Schublade. Hier präsentiere ich Ihnen echte technische Herausforderungen, die ich für meine Arbeitgeber und Partner im Quellcode gelöst habe:
        </p>
      </div>

      <!-- Categories Toggles Menu -->
      <div class="flex flex-wrap gap-1.5 bg-neutral-100 dark:bg-neutral-900 p-1.5 rounded-xl shrink-0">
        <button class="project-filter-btn px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white shadow-xs" data-category="All">Alle</button>
        <button class="project-filter-btn px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300" data-category="WordPress">WordPress</button>
        <button class="project-filter-btn px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300" data-category="WooCommerce">WooCommerce</button>
        <button class="project-filter-btn px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300" data-category="Shopify">Shopify</button>
        <button class="project-filter-btn px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300" data-category="Vanilla JS / Tech Stack">Vanilla JS</button>
        <button class="project-filter-btn px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300" data-category="SaaS / Next.js">SaaS / Next.js</button>
      </div>
    </div>

    <!-- Dynamic Projects Cards Container Grid -->
    <div id="projects-showroom" class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
      <!-- Project Cards dynamically generated in JS -->
    </div>

    <!-- Comparative Code Inspector Workspace -->
    <div class="pt-8" id="code-repo-viewer">
      
      <!-- Context headers -->
      <div class="max-w-3xl mb-6">
        <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold text-brand-accent uppercase bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 tracking-widest mb-4 w-max">
          <svg class="w-3.5 h-3.5 text-brand-accent shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
            <polyline points="16 18 22 12 16 6"></polyline>
            <polyline points="8 6 2 12 8 18"></polyline>
          </svg>
          <span>Tiefer Einblick // Code-Inspektor</span>
        </div>
        <p class="text-xs text-neutral-500 dark:text-neutral-300">
          Wählen Sie eines meiner repräsentativen Repository-Beispiele links aus. Vergleichen Sie den optimierten Quellcode direkt mit gängigen, generischen Copypaste-Schablonen (AI templates).
        </p>
      </div>

      <!-- Comparative widget board card -->
      <div class="border border-neutral-200 dark:border-neutral-800 rounded-2xl overflow-hidden shadow-sm flex flex-col xl:grid xl:grid-cols-12 bg-white dark:bg-neutral-950/80">
        
        <!-- File switcher sidebar panel (3 col) -->
        <div class="xl:col-span-3 bg-neutral-50 dark:bg-neutral-900/40 p-4 border-b xl:border-b-0 xl:border-r border-neutral-200 dark:border-neutral-800">
          <div class="text-xs font-mono text-neutral-400 uppercase tracking-widest mb-4 flex items-center gap-2">
            <!-- Terminal screen icon -->
            <svg class="w-3.5 h-3.5 text-brand-purple" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <polyline points="4 17 10 11 4 5"></polyline>
              <line x1="12" y1="19" x2="20" y2="19"></line>
            </svg>
            <span>Code-Repository</span>
          </div>

          <!-- Projects sidebar files selectors triggers -->
          <div id="inspector-file-sidebar" class="space-y-1">
            <!-- File Selector Buttons injected dynamically -->
          </div>

          <!-- Philosophy block -->
          <div class="mt-8 pt-4 border-t border-neutral-200 dark:border-neutral-800 hidden xl:block">
            <div class="text-[10px] uppercase font-bold tracking-widest text-neutral-400 mb-2">Philosophie</div>
            <p class="text-[11px] text-neutral-400 leading-relaxed font-sans">
              Als gelernter Entwickler verabscheue ich unsaubere WordPress/Shop-Arbeiten, die bei minimaler Last wegschmelzen. Klicken Sie auf den Vergleichstext rechts, um zu sehen wie sich mein semantischer Ansatz von unoptimiertem Code abgrenzt.
            </p>
          </div>
        </div>

        <!-- Real Code Viewer Area (9 col) -->
        <div class="xl:col-span-9 flex flex-col justify-between" id="snippet-viewer">
          
          <!-- Dynamic active project header -->
          <div class="px-5 py-3 border-b border-neutral-200 dark:border-neutral-800 bg-neutral-100/40 dark:bg-neutral-900/30 flex flex-wrap items-center justify-between gap-3 shrink-0">
            <div class="flex items-center gap-1.5 min-w-0">
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
              <span class="text-[10px] font-mono uppercase bg-neutral-200 dark:bg-neutral-800 text-neutral-500 dark:text-neutral-400 px-1.5 py-0.5 rounded shrink-0" id="inspector-project-category"></span>
              <h3 id="inspector-project-title" class="text-xs sm:text-sm font-bold text-neutral-800 dark:text-neutral-100 font-sans tracking-tight truncate"></h3>
            </div>
            <span id="inspector-project-impact" class="text-[9.5px] font-mono text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/15 truncate max-w-[280px]"></span>
          </div>
          
          <!-- Tab controller buttons bar -->
          <div class="bg-neutral-50 dark:bg-neutral-900/40 px-4 py-2 border-b border-neutral-200 dark:border-neutral-800 flex flex-wrap items-center justify-between gap-2">
            
            <!-- Quality Approach Switcher Toggle tabs -->
            <div class="flex bg-neutral-200/60 dark:bg-[#1a191d] p-0.5 rounded-lg text-[11px] font-mono shrink-0">
              <button id="tab-sauber" class="px-3 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1.5 bg-white dark:bg-neutral-950 text-neutral-900 dark:text-white font-bold shadow-xs">
                <!-- Shield verification check icon -->
                <svg class="w-3.5 h-3.5 text-emerald-500" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                </svg>
                <span>Sauberer Ansatz</span>
              </button>
              <button id="tab-slop" class="px-3 py-1 rounded-md transition-all cursor-pointer flex items-center gap-1.5 text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300">
                <!-- Warning alarm icon -->
                <svg class="w-3.5 h-3.5 text-rose-500" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                  <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                  <line x1="12" y1="9" x2="12" y2="13"></line>
                  <line x1="12" y1="17" x2="12.01" y2="17"></line>
                </svg>
                <span>KI-Template / Slop</span>
              </button>
            </div>

            <!-- Right actions copy codes button -->
            <div class="flex items-center gap-4">
              <span id="tab-feedback-italic" class="text-[10px] font-mono text-neutral-400 italic hidden sm:block">Wartungsfrei &amp; performant</span>
              <button id="btn-copy-snippet" class="flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-200/50 dark:bg-neutral-850 hover:bg-neutral-200 dark:hover:bg-neutral-800 text-xs font-mono text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer">
                <!-- Copy icon -->
                <svg id="copy-icon-svg" class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
                <!-- Success check icon -->
                <svg id="copy-success-svg" class="w-3.5 h-3.5 text-emerald-500 hidden" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                <span id="copy-btn-text">Kopieren</span>
              </button>
            </div>

          </div>

          <!-- Code Block Viewport -->
          <div class="relative bg-neutral-950 text-neutral-300 p-4 md:p-6 font-mono text-xs md:text-sm overflow-x-auto min-h-[340px] flex-1">
            <pre class="m-0 leading-relaxed font-mono select-text"><code id="inspector-code-block" class="language-javascript">
              // Code wird hier dynamisch geladen...
            </code></pre>
          </div>

        </div>

      </div>

    </div>

  </div>
</section>

<!-- CAREER HISTORY TIMELINE VIEW -->
<section id="experience" class="max-w-6xl mx-auto px-3 sm:px-6 md:px-12 lg:px-20 xl:px-32 border-b border-neutral-300 dark:border-neutral-700">
  <div class="flex flex-col dynamic-section-spacing">
    
    <!-- Headers title context -->
    <div class="max-w-3xl mb-4">
      <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold text-brand-accent uppercase bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 tracking-widest mb-4 w-max">
        <svg class="w-3.5 h-3.5 text-brand-accent shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10"></circle>
          <polyline points="12 6 12 12 16 14"></polyline>
        </svg>
        <span>Zeitstrahl</span>
      </div>
      <h2 class="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight mb-2 text-neutral-900 dark:text-neutral-50 dynamic-header-font">
        Meilensteine &amp; echte Learnings
      </h2>
      <p class="text-neutral-500 dark:text-neutral-400 leading-relaxed dynamic-body-font">
        Entwicklung passiert nicht im luftleeren Raum, sondern an echten Servern und unter harten Deadlines. Ein chronologischer Überblick über meine Rollen und praktischen Einsichten:
      </p>
    </div>

    <!-- Chronology records nodes list -->
    <div class="space-y-8">
      <div id="experience-timeline-container" class="relative space-y-12">
        <!-- Timeline nodes loaded dynamically by JS to handle toggling story context -->
      </div>
    </div>

  </div>
</section>

<!-- EXPERTS TECHNICAL SKILLS BOX -->
<section id="skills" class="max-w-6xl mx-auto px-3 sm:px-6 md:px-12 lg:px-20 xl:px-32 border-b border-neutral-300 dark:border-neutral-700">
  <div class="flex flex-col dynamic-section-spacing">
    
    <!-- Toolbox labels titles -->
    <div class="max-w-2xl mb-2">
      <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold text-brand-accent uppercase bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 tracking-widest mb-4 w-max">
        <svg class="w-3.5 h-3.5 text-brand-accent shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect>
          <rect x="9" y="9" width="6" height="6"></rect>
          <line x1="9" y1="1" x2="9" y2="4"></line>
          <line x1="15" y1="1" x2="15" y2="4"></line>
          <line x1="9" y1="20" x2="9" y2="23"></line>
          <line x1="15" y1="20" x2="15" y2="23"></line>
          <line x1="20" y1="9" x2="23" y2="9"></line>
          <line x1="20" y1="15" x2="23" y2="15"></line>
          <line x1="1" y1="9" x2="4" y2="9"></line>
          <line x1="1" y1="15" x2="4" y2="15"></line>
        </svg>
        <span>Toolbox</span>
      </div>
      <h2 class="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight mb-2 text-neutral-900 dark:text-neutral-50 dynamic-header-font">
        Mein Experten-Stack
      </h2>
      <p class="text-neutral-500 dark:text-neutral-400 leading-relaxed dynamic-body-font">
        Ich lerne nicht jedes neue Framework-Hype-Skript auswendig. Ich fokussiere mich auf die Fundamentals des Browsers: Ladezeit, Barrierefreiheit, Typsicherheit, Cache-Architektur. Das spart Latenzen und macht Systeme zukunftssicher.
      </p>
    </div>

    <!-- Visual Icon-Based Interactive Technology Grid -->
    <div class="mb-10">
      <h3 class="text-xs font-mono font-bold uppercase tracking-widest text-brand-accent mb-4">Core Technology Stack</h3>
      <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4">
        <!-- Tile 1: Next.js -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-neutral-900 dark:text-white mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm4.5 15.5l-4.5-5.85V16H10V8h1.5l4 5.2V8H17v9.5z"/>
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">Next.js 15</span>
          <span class="text-[8.5px] font-mono tracking-wider text-cyan-500 font-bold uppercase mt-1">Expert</span>
        </div>

        <!-- Tile 2: React -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-cyan-400 mb-2 transition-transform duration-300 group-hover:rotate-180 duration-[3000ms] ease-linear repeat-infinite" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(0 12 12)" />
            <ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(60 12 12)" />
            <ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(120 12 12)" />
            <circle cx="12" cy="12" r="1.5" fill="currentColor" />
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">React Client</span>
          <span class="text-[8.5px] font-mono tracking-wider text-cyan-500 font-bold uppercase mt-1">Expert</span>
        </div>

        <!-- Tile 3: Tailwind CSS -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-cyan-400 mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12.001 4.8c-3.2 0-5.2 1.6-6 4.8 1.2-1.6 2.6-2.2 4.2-1.8.913.228 1.565.89 2.288 1.624C13.666 10.618 15.027 12 18.001 12c3.2 0 5.2-1.6 6-4.8-1.2 1.6-2.6 2.2-4.2 1.8-.913-.228-1.565-.89-2.288-1.624C16.337 6.182 14.975 4.8 12.001 4.8zm-6 7.2c-3.2 0-5.2 1.6-6 4.8 1.2-1.6 2.6-2.2 4.2-1.8.913.228 1.565.89 2.288 1.624 1.177 1.194 2.538 2.576 5.512 2.576 3.2 0 5.2-1.6 6-4.8-1.2 1.6-2.6 2.2-4.2 1.8-.913-.228-1.565-.89-2.288-1.624C10.337 13.382 8.975 12 6.001 12z"/>
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">Tailwind CSS</span>
          <span class="text-[8.5px] font-mono tracking-wider text-cyan-500 font-bold uppercase mt-1">Expert</span>
        </div>

        <!-- Tile 4: TypeScript -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="currentColor">
            <path d="M4 2h16a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z" fill="#3178c6"/>
            <path d="M11.54 11.23h-2v5.18H8.11v-5.18H6.1v-1.14h5.44v1.14zm5.1 2.3c0 .87-.27 1.54-.8 2-.54.47-1.32.7-2.34.7a6.22 6.22 0 0 1-2.14-.35l.33-1.12c.57.18 1.13.27 1.67.27.65 0 1.11-.12 1.4-.35.28-.23.42-.58.42-1.04 0-.35-.09-.64-.26-.87-.17-.23-.42-.42-.76-.58s-.79-.34-1.35-.55c-.65-.24-1.16-.54-1.52-.92s-.54-.88-.54-1.49c0-.77.27-1.38.8-1.83.54-.45 1.25-.67 2.14-.67a5.55 5.55 0 0 1 1.88.31l-.27 1.1c-.5-.15-1-.22-1.5-.22-.57 0-1 .11-1.24.32-.25.21-.37.5-.37.89 0 .34.1.61.3.8s.47.37.8.53c.34.16.82.35 1.44.57.65.24 1.15.54 1.5.9.36.36.54.85.54 1.46z" fill="white"/>
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">TypeScript</span>
          <span class="text-[8.5px] font-mono tracking-wider text-cyan-500 font-bold uppercase mt-1">Expert</span>
        </div>

        <!-- Tile 5: PostgreSQL -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-cyan-500 mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 2L2 7l10 5 10-5-10-5z" />
            <path d="M2 17l10 5 10-5" />
            <path d="M2 12l10 5 10-5" />
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">PostgreSQL</span>
          <span class="text-[8.5px] font-mono tracking-wider text-violet-500 font-bold uppercase mt-1">Advanced</span>
        </div>

        <!-- Tile 6: Supabase -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-[#3ecf8e] mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12.984 2a.75.75 0 0 0-1.248-.557l-9.5 8.5A.75.75 0 0 0 2.75 11.25h8.266L8.034 22a.75.75 0 0 0 1.248.557l9.5-8.5A.75.75 0 0 0 18.25 12.75h-8.266l2.998-10.75z"/>
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">Supabase</span>
          <span class="text-[8.5px] font-mono tracking-wider text-violet-500 font-bold uppercase mt-1">Advanced</span>
        </div>

        <!-- Tile 7: WordPress -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-sky-600 mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18.2C7.472 20.2 3.8 16.528 3.8 12c0-1.517.406-2.932 1.11-4.165l5.228 14.288a8.171 8.171 0 0 1-6.338-10.123 8.163 8.163 0 0 1 12.39-4.2C15.111 6.84 14.4 7.6 14.4 8.44c0 .76.44 1.32.84 1.88.36.48.72 1 .72 1.68 0 .68-.4 1.24-.8 1.84-.4.6-.84 1.36-.84 2.24 0 .92.48 1.72 1.04 2.4l-3.36-10.08zm-1.88 0l-3-9h.44l2.56 7.68 2.56-7.68h.44z"/>
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">WordPress</span>
          <span class="text-[8.5px] font-mono tracking-wider text-cyan-500 font-bold uppercase mt-1">Expert</span>
        </div>

        <!-- Tile 8: Shopify -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-emerald-500 mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="currentColor">
            <path d="M18.8 6.4c0-.1-.1-.2-.2-.2h-4V4.6c0-1.4-1.1-2.5-2.5-2.5S9.6 3.2 9.6 4.6V6.2h-4c-.1 0-.2.1-.2.2L3.1 20.3c-.1.3.1.6.4.7l17.1.6h.4c.3-.1.4-.4.4-.7L18.8 6.4zM11.2 4.6c0-.6.5-1 1-1s1 .5 1 1V6.2h-2V4.6zM15 12h-4.4c.2-1 .9-1.6 1.8-1.6s1.6.6 1.8 1.6H15z" />
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">Shopify Dev</span>
          <span class="text-[8.5px] font-mono tracking-wider text-cyan-500 font-bold uppercase mt-1">Expert</span>
        </div>

        <!-- Tile 9: PHP -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-indigo-400 mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm3.1 13.5l-.5 2h-1.5l.5-2h-2l-.5 2H9l.5-2H7.5l.4-1.5H9.4l.6-2.5H8.5l.4-1.5H10.4l.5-2h1.5l-.5 2h2l-.5 2H15l-.4 1.5H13.1l-.6 2.5h1.5l-.4 1.5H12" />
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">PHP 8.x OOP</span>
          <span class="text-[8.5px] font-mono tracking-wider text-cyan-500 font-bold uppercase mt-1">Expert</span>
        </div>

        <!-- Tile 10: Redis -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-rose-500 mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 2L2 7l10 5 10-5-10-5z" />
            <path d="M2 17l10 5 10-5" />
            <path d="M2 12l10 5 10-5" />
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">Redis Cache</span>
          <span class="text-[8.5px] font-mono tracking-wider text-violet-500 font-bold uppercase mt-1">Advanced</span>
        </div>

        <!-- Tile 11: Git / CI/CD -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-[#f05032] mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="currentColor">
            <path d="M20.6 11.4L12.6 3.4c-.8-.8-2-.8-2.8 0L8.2 5.0 10.7 7.5c.6-.2 1.3-.1 1.9.4.5.5.7 1.2.5 1.9l2.5 2.5c.7-.2 1.4-.1 1.9.4.8.8.8 2 0 2.8s-2 .8-2.8 0c-.5-.5-.7-1.2-.5-1.9l-2.5-2.5c-.2.1-.5.2-.8.2s-.6-.1-.8-.2l-2.4 2.4c.2.6.1 1.3-.4 1.9-.8.8-2 .8-2.8 0s-.8-2 0-2.8c.5-.5 1.2-.7 1.9-.5l2.4-2.4c-.1-.2-.2-.5-.2-.8s.1-.6.2-.8L7.5 5.8 3.4 9.9c-.8.8-.8 2 0 2.8l8 8c.8.8 2 .8 2.8 0l6.4-6.4c.8-.9.8-2.1 0-2.9z"/>
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">Git Pipelines</span>
          <span class="text-[8.5px] font-mono tracking-wider text-cyan-500 font-bold uppercase mt-1">Expert</span>
        </div>

        <!-- Tile 12: Core Web Vitals -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-cyan-500 mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">Web Vitals</span>
          <span class="text-[8.5px] font-mono tracking-wider text-cyan-500 font-bold uppercase mt-1">Expert</span>
        </div>

        <!-- Tile 13: Prisma ORM -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-[#5a67d8] mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 2L2 19.5h20L12 2z" />
            <path d="M12 2v17.5" />
            <path d="M12 9.5L2 19.5" />
            <path d="M12 9.5l10 10" />
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">Prisma ORM</span>
          <span class="text-[8.5px] font-mono tracking-wider text-violet-500 font-bold uppercase mt-1">Advanced</span>
        </div>

        <!-- Tile 14: Figma -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="none">
            <path d="M8 5C8 6.65685 6.65685 8 5 8C3.34315 8 2 6.65685 2 5C2 3.34315 3.34315 2 5 2C6.65685 2 8 3.34315 8 5Z" fill="#F24E1E"/>
            <path d="M8 11C8 12.6569 6.65685 14 5 14C3.34315 14 2 12.6569 2 11C2 9.34315 3.34315 8 5 8C6.65685 8 8 9.34315 8 11Z" fill="#A259FF"/>
            <path d="M14 5C14 6.65685 12.6569 8 11 8C9.34315 8 8 6.65685 8 5C8 3.34315 9.34315 2 11 2C12.6569 2 14 3.34315 14 5Z" fill="#FF7262"/>
            <path d="M14 11C14 12.6569 12.6569 14 11 14C9.34315 14 8 12.6569 8 11V8H11C12.6569 8 14 9.34315 14 11Z" fill="#0ACF83"/>
            <path d="M8 17C8 18.6569 6.65685 20 5 20C3.34315 20 2 18.6569 2 17C2 15.3431 3.34315 14 5 14H8V17Z" fill="#1ABCFE"/>
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">Figma Dev</span>
          <span class="text-[8.5px] font-mono tracking-wider text-violet-500 font-bold uppercase mt-1">Advanced</span>
        </div>

        <!-- Tile 15: WooCommerce -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-[#7f54b3] mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="9" cy="21" r="1" />
            <circle cx="20" cy="21" r="1" />
            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">WooCommerce</span>
          <span class="text-[8.5px] font-mono tracking-wider text-cyan-500 font-bold uppercase mt-1">Expert</span>
        </div>

        <!-- Tile 16: CSS Properties -->
        <div class="group relative flex flex-col items-center justify-center p-4 rounded-xl border border-neutral-200/60 dark:border-neutral-800/60 bg-white/40 dark:bg-neutral-900/40 hover:bg-white dark:hover:bg-neutral-900/80 hover:border-brand-accent/50 dark:hover:border-brand-accent/50 hover:scale-[1.03] transition-all duration-300 shadow-sm cursor-default">
          <svg class="w-8 h-8 text-blue-500 mb-2 transition-transform duration-300 group-hover:scale-110" viewBox="0 0 24 24" fill="currentColor">
            <path d="M5 2l1.6 18 5.4 1.5 5.4-1.5L19 2H5zm10 6H9.3l.2 1.5H15l-.4 3.5-2.6.7-2.6-.7-.2-1.5H7.7l.4 3.2 3.9 1.1 3.9-1.1.5-4.7L16.6 8l-.6 0z"/>
          </svg>
          <span class="font-mono text-[11px] font-bold text-neutral-800 dark:text-neutral-200">CSS Grids</span>
          <span class="text-[8.5px] font-mono tracking-wider text-cyan-500 font-bold uppercase mt-1">Expert</span>
        </div>
      </div>
    </div>

    <!-- Technical stack categorizations quadrant grids -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
      
      <!-- Category 1: Frontend Core -->
      <div class="border border-neutral-200 dark:border-neutral-800 bg-white/60 dark:bg-neutral-950/20 p-5 rounded-2xl flex flex-col justify-between dynamic-card-spacing">
        <div>
          <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 border-b border-neutral-200/50 dark:border-neutral-800 pb-2 mb-3">Frontend Core</h3>
          <ul class="space-y-3">
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">Vanilla JS (ES6+)</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-cyan-500/10 text-cyan-500 border border-cyan-500/25 shrink-0">Expert</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Modulare Software-Strukturen, Event-Delegation, Performance-Tuning.</p>
            </li>
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">CSS Properties</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-cyan-500/10 text-cyan-500 border border-cyan-500/25 shrink-0">Expert</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Native CSS-Systeme, Grid/Flexbox Layouts, performante Übergänge.</p>
            </li>
          </ul>
        </div>
      </div>

      <!-- Category 2: E-Commerce & CMS -->
      <div class="border border-neutral-200 dark:border-neutral-800 bg-white/60 dark:bg-neutral-950/20 p-5 rounded-2xl flex flex-col justify-between dynamic-card-spacing">
        <div>
          <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 border-b border-neutral-200/50 dark:border-neutral-800 pb-2 mb-3">E-Commerce &amp; CMS</h3>
          <ul class="space-y-3">
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">WordPress Dev</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-cyan-500/10 text-cyan-500 border border-cyan-500/25 shrink-0">Expert</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Eigene Gutenberg Blöcke, Plugin-Entwicklung, Core-Hooks.</p>
            </li>
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">WooCommerce</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-cyan-500/10 text-cyan-500 border border-cyan-500/25 shrink-0">Expert</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Bedienerdefinierte Checkout-Verfahren, Filtermodifikationen, DB-Optimierung.</p>
            </li>
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">Shopify Liquid</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-cyan-500/10 text-cyan-500 border border-cyan-500/25 shrink-0">Expert</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Custom Sections, Metaobjects, AJAX Cart APIs und App-freie Setups.</p>
            </li>
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">ACF (Data Models)</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-cyan-500/10 text-cyan-500 border border-cyan-500/25 shrink-0">Expert</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Strukturierte Datenmodelle und UI-Integrationen.</p>
            </li>
          </ul>
        </div>
      </div>

      <!-- Category 3: Backend & Server -->
      <div class="border border-neutral-200 dark:border-neutral-800 bg-white/60 dark:bg-neutral-950/20 p-5 rounded-2xl flex flex-col justify-between dynamic-card-spacing">
        <div>
          <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 border-b border-neutral-200/50 dark:border-neutral-800 pb-2 mb-3">Backend &amp; Server</h3>
          <ul class="space-y-3">
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">PHP 8.x / OOP</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-cyan-500/10 text-cyan-500 border border-cyan-500/25 shrink-0">Expert</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Saubere Theme- und Klassenschnittstellen, Namespaces.</p>
            </li>
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">SQL Database</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-violet-500/10 text-violet-500 border border-violet-500/25 shrink-0">Advanced</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Tabellenindizes optimieren, schnelle Relational-Anfragen.</p>
            </li>
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">Redis Caching</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-violet-500/10 text-violet-500 border border-violet-500/25 shrink-0">Advanced</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Query-Daten im Hauptspeicher abfangen statt Datenbank-Overload.</p>
            </li>
          </ul>
        </div>
      </div>

      <!-- Category 4: Tools & Workflow -->
      <div class="border border-neutral-200 dark:border-neutral-800 bg-white/60 dark:bg-neutral-950/20 p-5 rounded-2xl flex flex-col justify-between dynamic-card-spacing">
        <div>
          <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 border-b border-neutral-200/50 dark:border-neutral-800 pb-2 mb-3">Tools &amp; Workflow</h3>
          <ul class="space-y-3">
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">Git &amp; CI/CD Pipelines</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-cyan-500/10 text-cyan-500 border border-cyan-500/25 shrink-0">Expert</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Subtree Deployments, Branching, GitHub Actions für FTP/Cloud Deploy.</p>
            </li>
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">Core Web Vitals</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-cyan-500/10 text-cyan-500 border border-cyan-500/25 shrink-0">Expert</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">LCP, INP und CLS Optimierung, Reduzierung von Blocking-Time.</p>
            </li>
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">Figma Handoff</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-violet-500/10 text-violet-500 border border-violet-500/25 shrink-0">Advanced</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Pixel-perfect Umsetzung von Designlayouts direkt in Code.</p>
            </li>
          </ul>
        </div>
      </div>

      <!-- Category 5: SaaS & Modern Web Stack -->
      <div class="border border-neutral-200 dark:border-neutral-800 bg-white/60 dark:bg-neutral-950/20 p-5 rounded-2xl flex flex-col justify-between dynamic-card-spacing">
        <div>
          <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 border-b border-neutral-200/50 dark:border-neutral-800 pb-2 mb-3">SaaS &amp; Modern Web Stack</h3>
          <ul class="space-y-3">
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">React &amp; Next.js</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-cyan-500/10 text-cyan-500 border border-cyan-500/25 shrink-0">Expert</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">SSG, SSR, App Router, RSC (React Server Components), Client-seitige Performance.</p>
            </li>
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">TypeScript</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-cyan-500/10 text-cyan-500 border border-cyan-500/25 shrink-0">Expert</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Strikte Typisierung, Generics, API-Festigkeit und fehlerfreie Build-Pipelines.</p>
            </li>
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">Prisma ORM</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-violet-500/10 text-violet-500 border border-violet-500/25 shrink-0">Advanced</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Typensichere Datenbankabfragen, relationale Schemamigrationen und Query-Optimierung.</p>
            </li>
            <li class="group">
              <div class="flex items-center justify-between gap-1">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">PostgreSQL / Supabase</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-violet-500/10 text-violet-500 border border-violet-500/25 shrink-0">Advanced</span>
              </div>
              <p class="text-[11px] text-neutral-600 dark:text-neutral-300 mt-0.5 leading-normal dynamic-body-font">Relationales Speichermanagement, Row-Level-Security (RLS), Edge Functions &amp; Realtime.</p>
            </li>
          </ul>
        </div>
      </div>

    </div>

  </div>
</section>

<!-- CAREER APPLICANT CONTACT AND COORDINATES FORM MODULE -->
<section id="contact" class="max-w-6xl mx-auto px-3 sm:px-6 md:px-12 lg:px-20 xl:px-32 border-b border-neutral-300 dark:border-neutral-700">
  <div class="flex flex-col dynamic-section-spacing">
    
    <!-- Headers title context text -->
    <div class="max-w-2xl text-center mx-auto">
      <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold text-brand-accent uppercase bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 tracking-widest mb-4 w-max mx-auto">
        <svg class="w-3.5 h-3.5 text-brand-accent shrink-0" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
          <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
          <polyline points="22,6 12,13 2,6"></polyline>
        </svg>
        <span>Kontakt &amp; Karriere</span>
      </div>
      <h2 class="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight mb-2 text-neutral-900 dark:text-neutral-50 dynamic-header-font">
        Suchen Sie Verstärkung für Ihr Team?
      </h2>
      <p class="text-neutral-500 dark:text-neutral-400 leading-relaxed dynamic-body-font text-center">
        Lassen Sie uns ins Gespräch kommen. Wenn Sie einen erfahrenen Lead Developer mit Fokus auf Performance, Web-Vitals und saubere Modul-Architekturen in Hamburg oder als Remote-Verstärkung suchen, freue ich mich auf Ihre Nachricht.
      </p>
    </div>

    <!-- Contact Layout grid -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      
      <!-- Left inputs form panel (6 col) -->
      <div class="lg:col-span-6">
        <form id="contact-team-form" class="space-y-4 w-full max-w-full bg-white dark:bg-neutral-950 p-6 md:p-8 border border-neutral-200 dark:border-neutral-800 rounded-2xl shadow-xs dynamic-card-spacing">
          
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <!-- Name input -->
            <div class="flex flex-col gap-1">
              <label for="form-name" class="text-xs font-mono text-neutral-500 dark:text-neutral-400 uppercase tracking-widest">Name *</label>
              <input
                id="form-name"
                type="text"
                required
                placeholder="Ihr vollständiger Name"
                class="w-full bg-neutral-50 dark:bg-neutral-900/40 p-2.5 rounded-lg border border-neutral-300 dark:border-neutral-800 font-sans text-xs text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 dark:placeholder-neutral-500 focus:ring-1 focus:brand-accent focus:outline-none"
              />
            </div>
            <!-- Email input -->
            <div class="flex flex-col gap-1">
              <label for="form-email" class="text-xs font-mono text-neutral-500 dark:text-neutral-400 uppercase tracking-widest">E-Mail *</label>
              <input
                id="form-email"
                type="email"
                required
                placeholder="ihrname@firma.de"
                class="w-full bg-neutral-50 dark:bg-neutral-900/40 p-2.5 rounded-lg border border-neutral-300 dark:border-neutral-800 font-sans text-xs text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 dark:placeholder-neutral-500 focus:ring-1 focus:brand-accent focus:outline-none"
              />
            </div>
          </div>

          <!-- Subject Position input -->
          <div class="flex flex-col gap-1">
            <label for="form-subject" class="text-xs font-mono text-neutral-500 dark:text-neutral-400 uppercase tracking-widest">Betreff / Position</label>
            <input
              id="form-subject"
              type="text"
              placeholder="z. B. Senior Frontend Developer, Technical Lead, Tech Interview..."
              class="w-full bg-neutral-50 dark:bg-neutral-900/40 p-2.5 rounded-lg border border-neutral-300 dark:border-neutral-800 font-sans text-xs text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 dark:placeholder-neutral-500 focus:ring-1 focus:brand-accent focus:outline-none"
            />
          </div>

          <!-- Message Description input -->
          <div class="flex flex-col gap-1">
            <label for="form-message" class="text-xs font-mono text-neutral-500 dark:text-neutral-400 uppercase tracking-widest">Stellenbeschreibung / Nachricht *</label>
            <textarea
              id="form-message"
              rows="5"
              required
              placeholder="Schildern Sie mir kurz Ihr Team, die anstehenden technischen Herausforderungen oder das Stellenangebot..."
              class="w-full bg-neutral-50 dark:bg-neutral-900/40 p-2.5 rounded-lg border border-neutral-300 dark:border-neutral-800 font-sans text-xs text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 dark:placeholder-neutral-500 focus:ring-1 focus:brand-accent focus:outline-none min-h-[120px]"
            ></textarea>
          </div>

          <!-- Feedback labels (Hidden by default) -->
          <p id="form-error-toast" class="text-xs font-mono text-rose-600 dark:text-rose-400 bg-rose-500/10 p-2.5 rounded border border-rose-500/20 hidden">
            Bitte füllen Sie alle markierten Pflichtfelder korrekt aus.
          </p>

          <p id="form-success-toast" class="text-xs font-mono text-emerald-500 bg-emerald-500/10 p-2.5 rounded border border-emerald-500/20 hidden">
            ✓ Danke für Ihre Anfrage! Ich antworte Ihnen persönlich innerhalb von 24 Stunden per E-Mail oder melde mich direkt auf LinkedIn.
          </p>

          <!-- Actions buttons footer -->
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
            <span class="text-[10px] font-mono text-neutral-400 uppercase">* Pflichtfeld</span>
            <button
              type="submit"
              id="btn-submit-contact"
              class="rounded-lg bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black py-2.5 px-5 text-xs font-mono font-bold transition-all shadow-xs flex items-center justify-center sm:justify-start gap-2 cursor-pointer focus:outline-none w-full sm:w-auto"
            >
              <!-- Send icon -->
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
              <span>Nachricht absenden</span>
            </button>
          </div>

        </form>
      </div>

      <!-- Right details social references sidebar (6 col) -->
      <div class="lg:col-span-6 space-y-6">
        
        <!-- Contact Cards coordinates detail list -->
        <div class="border border-neutral-200 dark:border-neutral-800 rounded-2xl p-5 bg-neutral-50/20 backdrop-blur-md dynamic-card-spacing">
          <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 mb-3">Karriere &amp; Recruiting</h3>
          <p class="text-xs font-sans text-neutral-500 leading-relaxed mb-4">
            Schreiben Sie mir gerne als Recruiter oder Engineering Lead direkt eine Nachricht. Ich antworte Ihnen zeitnah bezüglich Angeboten für Festanstellungen, anspruchsvollen Team-Rollen oder Coding-Herausforderungen.
          </p>
          
          <div class="space-y-3.5">
            
            <!-- Email row -->
            <div class="flex items-center gap-3">
              <!-- Mail envelopes icon -->
              <svg class="w-4 h-4 text-brand-accent shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                <polyline points="22,6 12,13 2,6"></polyline>
              </svg>
              <div class="flex flex-col">
                <span class="text-[9px] font-mono text-neutral-400 uppercase">E-Mail Adresse</span>
                <a href="mailto:hussein@thedevlab.de" class="text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300 hover:underline">
                  hussein@thedevlab.de
                </a>
              </div>
            </div>

            <!-- Phone row -->
            <div class="flex items-center gap-3">
              <!-- Phone icon -->
              <svg class="w-4 h-4 text-brand-accent shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
              </svg>
              <div class="flex flex-col">
                <span class="text-[9px] font-mono text-neutral-400 uppercase">Telefon</span>
                <a href="tel:+4915129664806" class="text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300 hover:underline">
                  +49 1512 9664806
                </a>
              </div>
            </div>

            <!-- Website row -->
            <div class="flex items-center gap-3">
              <!-- Globe icon -->
              <svg class="w-4 h-4 text-brand-accent shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="2" y1="12" x2="22" y2="12"></line>
                <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
              </svg>
              <div class="flex flex-col">
                <span class="text-[9px] font-mono text-neutral-400 uppercase">Webseite</span>
                <a href="https://www.thedevlab.de" target="_blank" rel="noopener noreferrer" class="text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300 hover:underline inline-flex items-center gap-1">
                  <span>www.thedevlab.de</span>
                </a>
              </div>
            </div>

            <!-- Github row -->
            <div class="flex items-center gap-3">
              <!-- GitHub icon -->
              <svg class="w-4 h-4 text-brand-accent shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path>
              </svg>
              <div class="flex flex-col">
                <span class="text-[9px] font-mono text-neutral-400 uppercase">Open-Source Profil</span>
                <a href="https://github.com/hussein-bawab" target="_blank" rel="noopener noreferrer" class="text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300 hover:underline inline-flex items-center gap-1">
                  <span>github.com/hussein-bawab</span>
                  <!-- ExternalLink icon -->
                  <svg class="w-2.5 h-2.5 opacity-60" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>
              </div>
            </div>

          </div>
        </div>

        <!-- Certifications Card -->
        <div class="border border-neutral-200 dark:border-neutral-800 rounded-2xl p-5 bg-neutral-50/20 backdrop-blur-md dynamic-card-spacing">
          <h3 class="text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 mb-3">Zertifizierungen &amp; Ausbildung</h3>
          <div class="space-y-4">
            <div>
              <div class="flex items-start justify-between gap-2.5">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">Certified Web Architect</span>
                <span class="text-[8.5px] uppercase font-mono px-1.5 py-0.2 rounded font-semibold bg-emerald-500/10 text-emerald-500 border border-emerald-500/25 shrink-0">Webmasters Europe</span>
              </div>
              <p class="text-[11px] text-neutral-500 dark:text-neutral-400 mt-1 font-sans leading-relaxed">
                Umfassendes Fachzertifikat (Okt 2017) der GFN AG Hamburg: JavaScript, PHP &amp; MySQL, Systemarchitektur, Online-Marketing und Interface Design.
              </p>
            </div>
            <div class="border-t border-neutral-200/50 dark:border-neutral-800/50 pt-3">
              <div class="flex items-start justify-between gap-2.5">
                <span class="text-xs font-bold text-neutral-800 dark:text-neutral-200">Bibliotheks- &amp; Informationsmanagement</span>
                <span class="text-[8px] uppercase font-mono text-neutral-400 shrink-0">HAW Hamburg</span>
              </div>
              <p class="text-[11px] text-neutral-500 dark:text-neutral-400 mt-1 font-sans leading-relaxed">
                Fachschwerpunkt: Informationsmanagement &amp; strukturierte Datenverarbeitung (Hochschulstudium 2005 - 2009).
              </p>
            </div>
          </div>
        </div>

        <!-- Download resume backup card trigger -->
        <div class="border border-dashed border-neutral-200 dark:border-neutral-800 rounded-2xl p-5 text-center dynamic-card-spacing">
          <!-- File download icon -->
          <svg class="w-6 h-6 text-brand-purple mx-auto mb-2 animate-bounce-slow" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
            <polyline points="7 10 12 15 17 10"></polyline>
            <line x1="12" y1="15" x2="12" y2="3"></line>
          </svg>
          <span class="text-xs font-bold block text-neutral-800 dark:text-neutral-200 font-sans">System-Ausweis &amp; Lebenslauf (PDF)</span>
          <span class="text-[10px] text-neutral-400 font-mono mt-1 block">Hussein_Bawab_CV_2026.pdf (1.2 MB)</span>
          <button id="btn-download-resume" class="mt-3.5 w-full bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 dark:hover:bg-neutral-800 hover:bg-neutral-200 rounded-lg py-2 text-xs font-mono font-bold text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer focus:outline-none">
            Downloaden
          </button>
        </div>

      </div>

    </div>

  </div>
</section>

<?php 
get_footer(); // ← WP-MIGRATION: Footer load
