<!doctype html>
<!-- ← WP-MIGRATION: Core WordPress Header dynamic attributes -->
<html <?php language_attributes(); ?> class="dark density-cozy">
  <head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
    <!-- Robots and Canonical managed by Yoast or fallback -->
    <?php wp_head(); // ← WP-MIGRATION: WordPress dynamic header hooks ?>
  </head>
  <body <?php body_class('bg-[#070708] text-neutral-800 dark:text-neutral-200 min-h-screen transition-colors duration-200 selection:bg-cyan-500/20 selection:text-cyan-500 dynamic-body-font'); ?>>
    
    <?php wp_body_open(); // ← WP-MIGRATION: WordPress body accessibility hook ?>

    <!-- Active Easter Egg Retro CRT overlays -->
    <div id="crt-overlay" class="pointer-events-none fixed inset-0 z-50 overflow-hidden bg-transparent border-none hidden">
      <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,180,216,0.06)_0%,transparent_100%)] pointer-events-none"></div>
      <div class="absolute inset-0 pointer-events-none scanlines-overlay opacity-15"></div>
    </div>

    <!-- Active Easter Egg Matrix notice bar -->
    <div id="matrix-head-bar" class="text-center bg-emerald-950/20 py-2.5 px-4 sticky top-0 z-50 text-[10px] font-mono text-emerald-300 flex items-center justify-center gap-4 border-b border-emerald-500/30 matrix-active-bar hidden">
      <span class="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
      <span>[Matrix Easter-Egg Aktiv] — Herzlichen Glückwunsch, Sie haben den CLI / Hack-Mode gestartet!</span>
      <button id="btn-deactivate-matrix" class="underline font-bold text-emerald-400 hover:text-emerald-200 transition-colors">Modus deinstallieren</button>
    </div>

    <!-- Wrap page content to isolate viewport-fixed overlay widgets -->
    <div id="portfolio-content-root" class="min-h-screen flex flex-col">

    <!-- MAIN NAV HEADER -->
    <header class="sticky top-0 z-40 bg-white/80 dark:bg-[#070708]/80 backdrop-blur-md border-b border-neutral-200/60 dark:border-neutral-800/60">
      <div class="max-w-6xl mx-auto px-3 sm:px-6 md:px-12 lg:px-20 xl:px-32 py-4 flex items-center justify-between">
        
        <!-- Personal branding title logo -->
        <div class="flex items-center gap-2">
          <a href="<?php echo esc_url(home_url('/')); ?>" class="flex items-center gap-2.5 group transition-all">
            <div class="w-7 h-7 flex-shrink-0">
              <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/logo.svg'); ?>" alt="HB Logo" class="w-full h-full object-contain" />
            </div>
            <span class="font-mono text-sm font-extrabold tracking-tight text-neutral-900 dark:text-neutral-50 group-hover:text-cyan-500 transition-colors">
              <?php bloginfo('name'); // ← WP-MIGRATION: Dynamic site brand name ?>
            </span>
          </a>
        </div>

        <!-- Desktop Navigation Items -->
        <nav class="hidden lg:flex items-center gap-6 font-mono text-[11px] uppercase tracking-wider">
          <a href="#vitals-analyzer" class="text-neutral-600 dark:text-neutral-400 hover:text-neutral-950 dark:hover:text-white transition-colors py-1">Speed-Auditor</a>
          <a href="#projects" class="text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors py-1">Fallstudien</a>
          <a href="#code-repo-viewer" class="text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors py-1">Code-Inspektor</a>
          <a href="#experience" class="text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors py-1">Erfahrung</a>
          <a href="#skills" class="text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors py-1">Toolbox</a>
        </nav>

        <!-- Dynamic Header actions bar -->
        <div class="flex items-center gap-3 md:gap-6">
          
          <!-- Live Timezone clock Hamburg -->
          <div class="hidden sm:flex items-center gap-1.5 font-mono text-[10px] text-neutral-400 dark:text-neutral-500 bg-neutral-100 dark:bg-neutral-900 border border-neutral-200/50 dark:border-neutral-800 px-2.5 py-1 rounded">
            <!-- Clock Icon -->
            <svg class="w-3.5 h-3.5 text-brand-accent animate-pulse" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="10"></circle>
              <polyline points="12 6 12 12 16 14"></polyline>
            </svg>
            <span>Hamburg Uhrzeit:</span>
            <span id="hamburg-clock" class="font-bold text-neutral-600 dark:text-neutral-300">13:36:40</span>
          </div>

          <!-- Color schema toggle button -->
          <button id="theme-toggle-btn" class="p-1.5 rounded-lg border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-900 text-neutral-500 dark:text-neutral-400 transition-colors cursor-pointer" title="Farbschema umschalten">
            <!-- Light/Dark toggle icon state -->
            <svg id="theme-icon-dark" class="w-4 h-4 hidden" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m0-12.728l.707.707m12.728 12.728l.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
            <svg id="theme-icon-light" class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
            </svg>
          </button>

          <!-- Action Anchor Link -->
          <a href="#contact" class="hidden md:flex items-center gap-1 text-xs font-mono font-bold text-neutral-900 dark:text-white border-b-2 border-brand-accent hover:border-brand-accent/40 transition-colors">
            <span>Kontakt</span>
            <svg class="w-3 h-3 text-brand-accent" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
              <polyline points="9 18 15 12 9 6"></polyline>
            </svg>
          </a>

          <!-- Mobile Hamburger Toggle icon -->
          <button id="mobile-hamburger-btn" class="flex lg:hidden p-1.5 rounded-lg border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-100 dark:hover:bg-neutral-900 text-neutral-500 dark:text-neutral-400 cursor-pointer" aria-label="Hauptmenü umschalten">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <line x1="4" y1="6" x2="20" y2="6"></line>
              <line x1="4" y1="12" x2="20" y2="12"></line>
              <line x1="4" y1="18" x2="20" y2="18"></line>
            </svg>
          </button>
        </div>

      </div>
    </header>

    <!-- MOBILE NAVIGATION DROPDOWN (Hidden by default) -->
    <div id="mobile-menu" class="sticky top-[57px] left-0 right-0 z-30 bg-white dark:bg-neutral-950 border-b border-neutral-200 dark:border-neutral-900 shadow-lg overflow-hidden lg:hidden hidden">
      <nav class="flex flex-col p-4 space-y-3.5 font-mono text-[11px] uppercase tracking-wider">
        <a href="#vitals-analyzer" class="text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors block py-2 border-b border-neutral-100 dark:border-neutral-900">Speed-Auditor</a>
        <a href="#projects" class="text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors block py-2 border-b border-neutral-100 dark:border-neutral-900">Fallstudien</a>
        <a href="#code-repo-viewer" class="text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors block py-2 border-b border-neutral-100 dark:border-neutral-900">Code-Inspektor</a>
        <a href="#experience" class="text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors block py-2 border-b border-neutral-100 dark:border-neutral-900">Erfahrung</a>
        <a href="#skills" class="text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors block py-2 border-b border-neutral-100 dark:border-neutral-900">Toolbox</a>
        <a href="#contact" class="text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white transition-colors block py-1 font-bold text-brand-accent">Kontakt aufnehmen →</a>
      </nav>
    </div>

    <!-- MAIN PORTFOLIO ROOT CONTAINER -->
    <main>
